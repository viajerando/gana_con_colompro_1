<?php
/**
 * Clase del panel de administración
 */
class GCC_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_gcc_get_game_details', array($this, 'ajax_get_game_details'));
        add_action('wp_ajax_gcc_export_data', array($this, 'ajax_export_data'));
    }
    
    /**
     * Añadir menú de administración
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Gana con Colompro', 'gana-con-colompro'),
            __('Gana con Colompro', 'gana-con-colompro'),
            'manage_options',
            'gana-con-colompro',
            array($this, 'render_statistics_page'),
            'dashicons-awards',
            56
        );
        
        add_submenu_page(
            'gana-con-colompro',
            __('Estadísticas', 'gana-con-colompro'),
            __('Estadísticas', 'gana-con-colompro'),
            'manage_options',
            'gana-con-colompro',
            array($this, 'render_statistics_page')
        );
        
        add_submenu_page(
            'gana-con-colompro',
            __('Configuración', 'gana-con-colompro'),
            __('Configuración', 'gana-con-colompro'),
            'manage_options',
            'gcc-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Cargar scripts del admin
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'gana-con-colompro') === false && strpos($hook, 'gcc-settings') === false) {
            return;
        }
        
        wp_enqueue_style('gcc-admin', GCC_PLUGIN_URL . 'assets/css/admin.css', array(), GCC_VERSION);
        wp_enqueue_script('gcc-admin', GCC_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), GCC_VERSION, true);
        
        // Chart.js para estadísticas
        if (strpos($hook, 'gana-con-colompro') !== false) {
            wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js', array(), '3.9.1');
        }
    }
    
    /**
     * Renderizar página de estadísticas
     */
    public function render_statistics_page() {
        $statistics = new GCC_Statistics();
        $stats = $statistics->get_all_statistics();
        ?>
        <div class="wrap gcc-admin-wrap">
            <h1><?php _e('Estadísticas de Gana con Colompro', 'gana-con-colompro'); ?></h1>
            
            <!-- Resumen general -->
            <div class="gcc-stats-grid">
                <div class="gcc-stat-box">
                    <h3><?php _e('Total de Juegos', 'gana-con-colompro'); ?></h3>
                    <div class="gcc-stat-number"><?php echo number_format($stats['total_games']); ?></div>
                    <p><?php _e('Juegos iniciados', 'gana-con-colompro'); ?></p>
                </div>
                
                <div class="gcc-stat-box">
                    <h3><?php _e('Juegos Completados', 'gana-con-colompro'); ?></h3>
                    <div class="gcc-stat-number"><?php echo number_format($stats['completed_games']); ?></div>
                    <p><?php echo sprintf(__('%s%% de conversión', 'gana-con-colompro'), 
                        $stats['total_games'] > 0 ? round(($stats['completed_games'] / $stats['total_games']) * 100, 1) : 0); ?></p>
                </div>
                
                <div class="gcc-stat-box">
                    <h3><?php _e('Cupones Generados', 'gana-con-colompro'); ?></h3>
                    <div class="gcc-stat-number"><?php echo number_format($stats['total_coupons']); ?></div>
                    <p><?php echo sprintf(__('%s usados', 'gana-con-colompro'), number_format($stats['used_coupons'])); ?></p>
                </div>
                
                <div class="gcc-stat-box">
                    <h3><?php _e('Valor Total de Bonos', 'gana-con-colompro'); ?></h3>
                    <div class="gcc-stat-number"><?php echo wc_price($stats['total_bonus_value']); ?></div>
                    <p><?php _e('En descuentos otorgados', 'gana-con-colompro'); ?></p>
                </div>
            </div>
            
            <!-- Gráficos -->
            <div class="gcc-charts-grid">
                <div class="gcc-chart-box">
                    <h3><?php _e('Resultados de Giros', 'gana-con-colompro'); ?></h3>
                    <canvas id="gcc-results-chart"></canvas>
                </div>
                
                <div class="gcc-chart-box">
                    <h3><?php _e('Distribución de Niveles Alcanzados', 'gana-con-colompro'); ?></h3>
                    <canvas id="gcc-levels-chart"></canvas>
                </div>
            </div>
            
            <!-- Tabla de juegos -->
            <div class="gcc-games-table">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="margin: 0;"><?php _e('Historial de Juegos', 'gana-con-colompro'); ?></h2>
                    <a href="<?php echo wp_nonce_url(admin_url('admin-ajax.php?action=gcc_export_data'), 'gcc_export'); ?>" class="button button-primary gcc-export-btn">
                        <?php _e('Exportar CSV', 'gana-con-colompro'); ?>
                    </a>
                </div>
                <?php wp_nonce_field('gcc_admin_action', 'gcc_admin_nonce'); ?>
                <?php $this->render_games_table(); ?>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Gráfico de resultados
            var resultsCtx = document.getElementById('gcc-results-chart').getContext('2d');
            var resultsChart = new Chart(resultsCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Ganas', 'Repites', 'Pierdes'],
                    datasets: [{
                        data: [
                            <?php echo isset($stats['results']['win']) ? $stats['results']['win'] : 0; ?>,
                            <?php echo isset($stats['results']['repeat']) ? $stats['results']['repeat'] : 0; ?>,
                            <?php echo isset($stats['results']['lose']) ? $stats['results']['lose'] : 0; ?>
                        ],
                        backgroundColor: ['#28a745', '#007bff', '#dc3545']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
            
            // Gráfico de niveles
            var levelsCtx = document.getElementById('gcc-levels-chart').getContext('2d');
            var levelsChart = new Chart(levelsCtx, {
                type: 'bar',
                data: {
                    labels: ['Nivel 1', 'Nivel 2', 'Nivel 3', 'Nivel 4', 'Nivel 5', 'Nivel 6', 'Nivel 7', 'Nivel 8'],
                    datasets: [{
                        label: 'Jugadores que alcanzaron',
                        data: <?php echo json_encode($stats['levels_distribution']); ?>,
                        backgroundColor: '#007bff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Renderizar tabla de juegos
     */
    private function render_games_table() {
        $page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
        $per_page = 20;
        $games = GCC_Database::get_games($page, $per_page);
        $total_games = GCC_Database::count_games();
        $total_pages = ceil($total_games / $per_page);
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('ID Pedido', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Usuario', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Estado', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Nivel', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Premio', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Cupón', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Fecha', 'gana-con-colompro'); ?></th>
                    <th><?php _e('Acciones', 'gana-con-colompro'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($games as $game) : ?>
                <tr>
                    <td>
                        <a href="<?php echo admin_url('post.php?post=' . $game->order_id . '&action=edit'); ?>">
                            #<?php echo $game->order_id; ?>
                        </a>
                    </td>
                    <td><?php echo esc_html($game->user_email); ?></td>
                    <td>
                        <span class="gcc-status-badge gcc-status-<?php echo esc_attr($game->status); ?>">
                            <?php echo $this->get_status_label($game->status); ?>
                        </span>
                    </td>
                    <td><?php echo $game->current_level; ?></td>
                    <td>
                        <?php if ($game->reward_percentage > 0) : ?>
                            <?php echo $game->reward_percentage; ?>% (<?php echo wc_price($game->reward_amount); ?>)
                        <?php else : ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($game->coupon_code) : ?>
                            <code><?php echo $game->coupon_code; ?></code>
                            <?php if ($game->used_at) : ?>
                                <span class="gcc-used"><?php _e('(Usado)', 'gana-con-colompro'); ?></span>
                            <?php endif; ?>
                        <?php else : ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?php echo date_i18n(get_option('date_format'), strtotime($game->created_at)); ?></td>
                    <td>
                        <a href="#" class="button button-small gcc-view-details" data-game-id="<?php echo $game->id; ?>">
                            <?php _e('Ver detalles', 'gana-con-colompro'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php if ($total_pages > 1) : ?>
        <div class="tablenav">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $total_pages,
                    'current' => $page
                ));
                ?>
            </div>
        </div>
        <?php endif;
    }
    
    /**
     * Obtener etiqueta de estado
     */
    private function get_status_label($status) {
        $labels = array(
            'pending' => __('Pendiente', 'gana-con-colompro'),
            'playing' => __('Jugando', 'gana-con-colompro'),
            'completed' => __('Completado', 'gana-con-colompro'),
            'claimed' => __('Reclamado', 'gana-con-colompro'),
            'lost' => __('Perdido', 'gana-con-colompro')
        );
        
        return isset($labels[$status]) ? $labels[$status] : $status;
    }
    
    /**
     * Renderizar página de configuración
     */
    public function render_settings_page() {
        $settings = new GCC_Settings();
        $settings->render();
    }
    
    /**
     * AJAX: Obtener detalles del juego
     */
    public function ajax_get_game_details() {
        // Verificar nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gcc_admin_action')) {
            wp_die('Nonce verification failed');
        }
        
        // Verificar permisos
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $game_id = isset($_POST['game_id']) ? intval($_POST['game_id']) : 0;
        if (!$game_id) {
            wp_send_json_error('ID de juego inválido');
        }
        
        // Obtener datos del juego
        $game = GCC_Database::get_game($game_id);
        if (!$game) {
            wp_send_json_error('Juego no encontrado');
        }
        
        // Obtener giros
        $spins = GCC_Database::get_game_spins($game_id);
        
        // Preparar datos
        $data = array(
            'order_id' => $game->order_id,
            'user_email' => $game->user_email,
            'status' => $game->status,
            'status_label' => $this->get_status_label($game->status),
            'current_level' => $game->current_level,
            'reward_percentage' => $game->reward_percentage,
            'reward_amount' => wc_price($game->reward_amount),
            'coupon_code' => $game->coupon_code,
            'started_at' => $game->started_at ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($game->started_at)) : null,
            'completed_at' => $game->completed_at ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($game->completed_at)) : null,
            'spins' => array()
        );
        
        // Agregar giros
        foreach ($spins as $spin) {
            $data['spins'][] = array(
                'level' => $spin->level,
                'result' => $spin->result,
                'result_label' => $this->get_result_label($spin->result)
            );
        }
        
        wp_send_json_success($data);
    }
    
    /**
     * AJAX: Exportar datos
     */
    public function ajax_export_data() {
        // Verificar nonce
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'gcc_export')) {
            wp_die('Nonce verification failed');
        }
        
        // Verificar permisos
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $statistics = new GCC_Statistics();
        $statistics->export_to_csv();
    }
    
    /**
     * Obtener etiqueta de resultado
     */
    private function get_result_label($result) {
        $labels = array(
            'win' => __('Ganó', 'gana-con-colompro'),
            'repeat' => __('Repitió', 'gana-con-colompro'),
            'lose' => __('Perdió', 'gana-con-colompro')
        );
        
        return isset($labels[$result]) ? $labels[$result] : $result;
    }
}