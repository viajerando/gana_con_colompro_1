<?php
/**
 * Clase de configuración
 */
class GCC_Settings {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    /**
     * Registrar configuraciones
     */
    public function register_settings() {
        // No registrar aquí, se hace en el render
    }
    
    /**
     * Renderizar página de configuración
     */
    public function render() {
        if (isset($_GET['settings-updated'])) {
            add_settings_error('gcc_messages', 'gcc_message', __('Configuración guardada', 'gana-con-colompro'), 'updated');
        }
        
        settings_errors('gcc_messages');
        
        $settings = get_option('gcc_settings', array());
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('gcc_settings_action', 'gcc_settings_nonce'); ?>
                
                <div class="gcc-settings-container">
                    <!-- Probabilidades -->
                    <div class="gcc-settings-section">
                        <h2><?php _e('Probabilidades del Juego', 'gana-con-colompro'); ?></h2>
                        <p class="description"><?php _e('Las probabilidades deben sumar exactamente 100%', 'gana-con-colompro'); ?></p>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="probability_win"><?php _e('Probabilidad de Ganar (%)', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="probability_win" name="gcc_settings[probability_win]" 
                                           value="<?php echo esc_attr($settings['probability_win'] ?? 33); ?>" 
                                           min="0" max="100" step="0.1" class="small-text probability-input" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="probability_repeat"><?php _e('Probabilidad de Repetir (%)', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="probability_repeat" name="gcc_settings[probability_repeat]" 
                                           value="<?php echo esc_attr($settings['probability_repeat'] ?? 34); ?>" 
                                           min="0" max="100" step="0.1" class="small-text probability-input" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="probability_lose"><?php _e('Probabilidad de Perder (%)', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="probability_lose" name="gcc_settings[probability_lose]" 
                                           value="<?php echo esc_attr($settings['probability_lose'] ?? 33); ?>" 
                                           min="0" max="100" step="0.1" class="small-text probability-input" />
                                    <p class="description">
                                        <?php _e('Total:', 'gana-con-colompro'); ?> <span id="probability-total">100</span>%
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Colores -->
                    <div class="gcc-settings-section">
                        <h2><?php _e('Colores de la Ruleta', 'gana-con-colompro'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="color_win"><?php _e('Color para Ganar', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="color" id="color_win" name="gcc_settings[color_win]" 
                                           value="<?php echo esc_attr($settings['color_win'] ?? '#28a745'); ?>" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="color_repeat"><?php _e('Color para Repetir', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="color" id="color_repeat" name="gcc_settings[color_repeat]" 
                                           value="<?php echo esc_attr($settings['color_repeat'] ?? '#007bff'); ?>" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="color_lose"><?php _e('Color para Perder', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="color" id="color_lose" name="gcc_settings[color_lose]" 
                                           value="<?php echo esc_attr($settings['color_lose'] ?? '#dc3545'); ?>" />
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Configuración del juego -->
                    <div class="gcc-settings-section">
                        <h2><?php _e('Configuración del Juego', 'gana-con-colompro'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <?php _e('Mostrar en página de agradecimiento', 'gana-con-colompro'); ?>
                                </th>
                                <td>
                                    <label for="show_game_on_thankyou">
                                        <input type="checkbox" id="show_game_on_thankyou" name="gcc_settings[show_game_on_thankyou]" 
                                               value="1" <?php checked($settings['show_game_on_thankyou'] ?? true, true); ?> />
                                        <?php _e('Mostrar invitación al juego después del pago', 'gana-con-colompro'); ?>
                                    </label>
                                    <p class="description"><?php _e('Si está activo, el cliente verá la invitación al juego inmediatamente después de completar el pago.', 'gana-con-colompro'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="coupon_duration_days"><?php _e('Duración del Cupón (días)', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="coupon_duration_days" name="gcc_settings[coupon_duration_days]" 
                                           value="<?php echo esc_attr($settings['coupon_duration_days'] ?? 60); ?>" 
                                           min="1" max="365" class="small-text" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="invitation_delay_hours"><?php _e('Retraso de Invitación (horas)', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="invitation_delay_hours" name="gcc_settings[invitation_delay_hours]" 
                                           value="<?php echo esc_attr($settings['invitation_delay_hours'] ?? 1); ?>" 
                                           min="0" max="24" class="small-text" />
                                    <p class="description"><?php _e('Tiempo de espera antes de enviar el email de invitación', 'gana-con-colompro'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <?php _e('Sonidos', 'gana-con-colompro'); ?>
                                </th>
                                <td>
                                    <label for="enable_sounds">
                                        <input type="checkbox" id="enable_sounds" name="gcc_settings[enable_sounds]" 
                                               value="1" <?php checked($settings['enable_sounds'] ?? true, true); ?> />
                                        <?php _e('Habilitar efectos de sonido', 'gana-con-colompro'); ?>
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Textos -->
                    <div class="gcc-settings-section">
                        <h2><?php _e('Textos Personalizables', 'gana-con-colompro'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="game_title"><?php _e('Título del Juego', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="game_title" name="gcc_settings[game_title]" 
                                           value="<?php echo esc_attr($settings['game_title'] ?? 'Gana con Colompro'); ?>" 
                                           class="regular-text" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="reward_message"><?php _e('Mensaje al Entregar Bono', 'gana-con-colompro'); ?></label>
                                </th>
                                <td>
                                    <textarea id="reward_message" name="gcc_settings[reward_message]" 
                                              rows="3" cols="50" class="large-text"><?php 
                                        echo esc_textarea($settings['reward_message'] ?? '¡Tenés 60 días para usar este bono! ¡Aprovechalo pues!'); 
                                    ?></textarea>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Email -->
                    <div class="gcc-settings-section">
                        <h2><?php _e('Configuración de Email', 'gana-con-colompro'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <?php _e('Recordatorios', 'gana-con-colompro'); ?>
                                </th>
                                <td>
                                    <label for="enable_reminders">
                                        <input type="checkbox" id="enable_reminders" name="gcc_settings[enable_reminders]" 
                                               value="1" <?php checked($settings['enable_reminders'] ?? true, true); ?> />
                                        <?php _e('Habilitar recordatorios automáticos', 'gana-con-colompro'); ?>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <?php _e('Días de Recordatorio', 'gana-con-colompro'); ?>
                                </th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="gcc_settings[reminder_days][]" value="30" 
                                               <?php checked(in_array(30, $settings['reminder_days'] ?? array(30, 15, 7, 3))); ?> />
                                        <?php _e('30 días antes', 'gana-con-colompro'); ?>
                                    </label><br>
                                    <label>
                                        <input type="checkbox" name="gcc_settings[reminder_days][]" value="15" 
                                               <?php checked(in_array(15, $settings['reminder_days'] ?? array(30, 15, 7, 3))); ?> />
                                        <?php _e('15 días antes', 'gana-con-colompro'); ?>
                                    </label><br>
                                    <label>
                                        <input type="checkbox" name="gcc_settings[reminder_days][]" value="7" 
                                               <?php checked(in_array(7, $settings['reminder_days'] ?? array(30, 15, 7, 3))); ?> />
                                        <?php _e('7 días antes', 'gana-con-colompro'); ?>
                                    </label><br>
                                    <label>
                                        <input type="checkbox" name="gcc_settings[reminder_days][]" value="3" 
                                               <?php checked(in_array(3, $settings['reminder_days'] ?? array(30, 15, 7, 3))); ?> />
                                        <?php _e('3 días antes', 'gana-con-colompro'); ?>
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <?php submit_button(__('Guardar Configuración', 'gana-con-colompro')); ?>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Calcular total de probabilidades
            function updateProbabilityTotal() {
                var total = 0;
                $('.probability-input').each(function() {
                    total += parseFloat($(this).val()) || 0;
                });
                
                $('#probability-total').text(total.toFixed(1));
                
                if (Math.abs(total - 100) > 0.1) {
                    $('#probability-total').css('color', '#dc3545');
                } else {
                    $('#probability-total').css('color', '#28a745');
                }
            }
            
            $('.probability-input').on('input', updateProbabilityTotal);
            updateProbabilityTotal();
        });
        </script>
        <?php
    }
    
    /**
     * Sanitizar configuraciones
     */
    public function sanitize_settings($input) {
        $sanitized = array();
        
        // Probabilidades
        $sanitized['probability_win'] = isset($input['probability_win']) ? floatval($input['probability_win']) : 33;
        $sanitized['probability_repeat'] = isset($input['probability_repeat']) ? floatval($input['probability_repeat']) : 34;
        $sanitized['probability_lose'] = isset($input['probability_lose']) ? floatval($input['probability_lose']) : 33;
        
        // Validar que sumen 100
        if (!GCC_Security::validate_probabilities($sanitized['probability_win'], $sanitized['probability_repeat'], $sanitized['probability_lose'])) {
            add_settings_error('gcc_messages', 'gcc_error', __('Las probabilidades deben sumar exactamente 100%', 'gana-con-colompro'), 'error');
        }
        
        // Colores
        $sanitized['color_win'] = isset($input['color_win']) ? sanitize_hex_color($input['color_win']) : '#28a745';
        $sanitized['color_repeat'] = isset($input['color_repeat']) ? sanitize_hex_color($input['color_repeat']) : '#007bff';
        $sanitized['color_lose'] = isset($input['color_lose']) ? sanitize_hex_color($input['color_lose']) : '#dc3545';
        
        // Configuración del juego
        $sanitized['show_game_on_thankyou'] = isset($input['show_game_on_thankyou']) ? true : false;
        $sanitized['coupon_duration_days'] = isset($input['coupon_duration_days']) ? intval($input['coupon_duration_days']) : 60;
        $sanitized['invitation_delay_hours'] = isset($input['invitation_delay_hours']) ? intval($input['invitation_delay_hours']) : 1;
        $sanitized['enable_sounds'] = isset($input['enable_sounds']) ? true : false;
        
        // Textos
        $sanitized['game_title'] = isset($input['game_title']) ? sanitize_text_field($input['game_title']) : 'Gana con Colompro';
        $sanitized['reward_message'] = isset($input['reward_message']) ? sanitize_textarea_field($input['reward_message']) : '¡Tenés 60 días para usar este bono! ¡Aprovechalo pues!';
        
        // Email
        $sanitized['enable_reminders'] = isset($input['enable_reminders']) ? true : false;
        $sanitized['reminder_days'] = isset($input['reminder_days']) ? array_map('intval', $input['reminder_days']) : array(30, 15, 7, 3);
        
        return $sanitized;
    }
}