<?php
/**
 * Clase de estadísticas
 */
class GCC_Statistics {
    
    /**
     * Obtener todas las estadísticas
     */
    public function get_all_statistics() {
        $stats = GCC_Database::get_statistics();
        
        // Añadir distribución de niveles
        $stats['levels_distribution'] = $this->get_levels_distribution();
        
        // Calcular promedios
        $stats['average_level'] = $this->get_average_level();
        $stats['conversion_rate'] = $this->get_conversion_rate();
        
        return $stats;
    }
    
    /**
     * Obtener distribución de niveles alcanzados
     */
    private function get_levels_distribution() {
        global $wpdb;
        
        $distribution = array_fill(1, 8, 0);
        
        $results = $wpdb->get_results(
            "SELECT current_level, COUNT(*) as count 
            FROM {$wpdb->prefix}gcc_games 
            WHERE status IN ('playing', 'completed', 'claimed', 'lost') 
            AND current_level > 0
            GROUP BY current_level"
        );
        
        foreach ($results as $result) {
            if ($result->current_level >= 1 && $result->current_level <= 8) {
                $distribution[$result->current_level] = intval($result->count);
            }
        }
        
        return array_values($distribution);
    }
    
    /**
     * Obtener nivel promedio alcanzado
     */
    private function get_average_level() {
        global $wpdb;
        
        $avg = $wpdb->get_var(
            "SELECT AVG(current_level) 
            FROM {$wpdb->prefix}gcc_games 
            WHERE status IN ('playing', 'completed', 'claimed', 'lost') 
            AND current_level > 0"
        );
        
        return $avg ? round($avg, 1) : 0;
    }
    
    /**
     * Obtener tasa de conversión
     */
    private function get_conversion_rate() {
        global $wpdb;
        
        $total = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games WHERE status != 'pending'"
        );
        
        $claimed = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games WHERE status = 'claimed'"
        );
        
        if ($total > 0) {
            return round(($claimed / $total) * 100, 1);
        }
        
        return 0;
    }
    
    /**
     * Obtener estadísticas por período
     */
    public function get_period_statistics($start_date, $end_date) {
        global $wpdb;
        
        $stats = array();
        
        // Juegos en el período
        $stats['period_games'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games 
            WHERE created_at >= %s AND created_at <= %s",
            $start_date . ' 00:00:00',
            $end_date . ' 23:59:59'
        ));
        
        // Cupones generados en el período
        $stats['period_coupons'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons 
            WHERE created_at >= %s AND created_at <= %s",
            $start_date . ' 00:00:00',
            $end_date . ' 23:59:59'
        ));
        
        // Valor de cupones en el período
        $stats['period_value'] = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(amount) FROM {$wpdb->prefix}gcc_coupons 
            WHERE created_at >= %s AND created_at <= %s",
            $start_date . ' 00:00:00',
            $end_date . ' 23:59:59'
        ));
        
        return $stats;
    }
    
    /**
     * Obtener mejores jugadores
     */
    public function get_top_players($limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT 
                user_email,
                COUNT(*) as games_played,
                MAX(current_level) as max_level,
                SUM(CASE WHEN status = 'claimed' THEN 1 ELSE 0 END) as prizes_claimed,
                SUM(reward_amount) as total_rewards
            FROM {$wpdb->prefix}gcc_games
            WHERE status != 'pending'
            GROUP BY user_email
            ORDER BY total_rewards DESC
            LIMIT %d",
            $limit
        ));
    }
    
    /**
     * Obtener estadísticas de cupones
     */
    public function get_coupon_statistics() {
        global $wpdb;
        
        $stats = array();
        
        // Cupones por expirar
        $stats['expiring_soon'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons 
            WHERE used_at IS NULL 
            AND expires_at >= NOW() 
            AND expires_at <= DATE_ADD(NOW(), INTERVAL 7 DAY)"
        );
        
        // Cupones expirados sin usar
        $stats['expired_unused'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons 
            WHERE used_at IS NULL 
            AND expires_at < NOW()"
        );
        
        // Tasa de uso
        $total_coupons = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons"
        );
        
        $used_coupons = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons WHERE used_at IS NOT NULL"
        );
        
        $stats['usage_rate'] = $total_coupons > 0 ? round(($used_coupons / $total_coupons) * 100, 1) : 0;
        
        // Tiempo promedio hasta uso
        $avg_time = $wpdb->get_var(
            "SELECT AVG(TIMESTAMPDIFF(DAY, created_at, used_at)) 
            FROM {$wpdb->prefix}gcc_coupons 
            WHERE used_at IS NOT NULL"
        );
        
        $stats['avg_days_to_use'] = $avg_time ? round($avg_time, 1) : 0;
        
        return $stats;
    }
    
    /**
     * Exportar estadísticas a CSV
     */
    public function export_to_csv() {
        $filename = 'gcc-statistics-' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Headers
        fputcsv($output, array(
            'Order ID',
            'User Email',
            'Status',
            'Level',
            'Reward %',
            'Reward Amount',
            'Coupon Code',
            'Used',
            'Created Date'
        ));
        
        // Data
        $games = GCC_Database::get_games(1, 9999);
        
        foreach ($games as $game) {
            fputcsv($output, array(
                $game->order_id,
                $game->user_email,
                $game->status,
                $game->current_level,
                $game->reward_percentage,
                $game->reward_amount,
                $game->coupon_code ?: '-',
                $game->used_at ? 'Yes' : 'No',
                $game->created_at
            ));
        }
        
        fclose($output);
        exit;
    }
}