<?php
/**
 * Controlador del juego
 */
class GCC_Game_Controller {
    
    /**
     * AJAX: Girar la ruleta
     */
    public static function ajax_spin_wheel() {
        // Log para debug
        error_log('GCC: ajax_spin_wheel called');
        error_log('POST data: ' . print_r($_POST, true));
        
        // Verificar nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gcc_game_nonce')) {
            error_log('GCC: Nonce verification failed');
            wp_send_json_error(__('Error de seguridad. Por favor recarga la página.', 'gana-con-colompro'));
            return;
        }
        
        // Sanitizar datos
        $data = GCC_Security::sanitize_game_data($_POST);
        
        if (!isset($data['order_id']) || !isset($data['token'])) {
            error_log('GCC: Missing order_id or token');
            wp_send_json_error(__('Datos inválidos', 'gana-con-colompro'));
            return;
        }
        
        // Verificar token
        if (!GCC_Security::verify_token($data['order_id'], $data['token'])) {
            error_log('GCC: Token verification failed');
            wp_send_json_error(__('Token inválido', 'gana-con-colompro'));
            return;
        }
        
        // Verificar que puede jugar
        $can_play = GCC_Security::can_play_game($data['order_id']);
        if (is_array($can_play) && isset($can_play['error'])) {
            wp_send_json_error($can_play['error']);
            return;
        }
        
        // Obtener juego
        $game = GCC_Database::get_game_by_order($data['order_id']);
        if (!$game) {
            wp_send_json_error(__('Juego no encontrado', 'gana-con-colompro'));
            return;
        }
        
        // Girar la ruleta
        $result = GCC_Game_Engine::spin($game->id);
        
        if (isset($result['error'])) {
            wp_send_json_error($result['error']);
            return;
        }
        
        // Preparar respuesta
        $response = array(
            'result' => $result['result'],
            'level' => $result['level'],
            'reward_percentage' => $result['reward_percentage'],
            'reward_amount' => isset($result['reward_amount']) ? wc_price($result['reward_amount']) : '',
            'game_over' => isset($result['game_over']) ? $result['game_over'] : false,
            'game_completed' => isset($result['game_completed']) ? $result['game_completed'] : false
        );
        
        // NO añadir información de animación aquí - se maneja en JavaScript
        // La animación se calcula en el cliente basándose en el resultado
        
        wp_send_json_success($response);
    }
    
    /**
     * AJAX: Reclamar recompensa
     */
    public static function ajax_claim_reward() {
        // Log para debug
        error_log('GCC: ajax_claim_reward called');
        error_log('POST data: ' . print_r($_POST, true));
        
        // Verificar nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gcc_game_nonce')) {
            error_log('GCC: Nonce verification failed');
            wp_send_json_error(__('Error de seguridad. Por favor recarga la página.', 'gana-con-colompro'));
            return;
        }
        
        // Sanitizar datos
        $data = GCC_Security::sanitize_game_data($_POST);
        
        if (!isset($data['order_id']) || !isset($data['token'])) {
            error_log('GCC: Missing order_id or token');
            wp_send_json_error(__('Datos inválidos', 'gana-con-colompro'));
            return;
        }
        
        // Verificar token
        if (!GCC_Security::verify_token($data['order_id'], $data['token'])) {
            error_log('GCC: Token verification failed');
            wp_send_json_error(__('Token inválido', 'gana-con-colompro'));
            return;
        }
        
        // Obtener juego
        $game = GCC_Database::get_game_by_order($data['order_id']);
        if (!$game) {
            error_log('GCC: Game not found for order ' . $data['order_id']);
            wp_send_json_error(__('Juego no encontrado', 'gana-con-colompro'));
            return;
        }
        
        error_log('GCC: Game found - ID: ' . $game->id . ', Status: ' . $game->status . ', Reward: ' . $game->reward_percentage . '%');
        
        // Reclamar premio
        $result = GCC_Game_Engine::claim_reward($game->id);
        
        error_log('GCC: Claim result: ' . print_r($result, true));
        
        if (isset($result['error'])) {
            wp_send_json_error($result['error']);
            return;
        }
        
        wp_send_json_success($result);
    }
}