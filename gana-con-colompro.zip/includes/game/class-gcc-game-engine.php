<?php
/**
 * Motor del juego
 */
class GCC_Game_Engine {
    
    /**
     * Niveles y recompensas
     */
    private static $levels = array(
        1 => 1,    // 1%
        2 => 2,    // 2%
        3 => 4,    // 4%
        4 => 8,    // 8%
        5 => 15,   // 15%
        6 => 30,   // 30%
        7 => 50,   // 50%
        8 => 100   // 100%
    );
    
    /**
     * Resultados posibles
     */
    const RESULT_WIN = 'win';
    const RESULT_REPEAT = 'repeat';
    const RESULT_LOSE = 'lose';
    
    /**
     * Girar la ruleta
     */
    public static function spin($game_id) {
        global $wpdb; // Añadir esta línea
        
        // Obtener juego
        $game = GCC_Database::get_game($game_id);
        if (!$game) {
            return array('error' => __('Juego no encontrado', 'gana-con-colompro'));
        }
        
        // Verificar si puede jugar
        if ($game->status !== 'pending' && $game->status !== 'playing') {
            return array('error' => __('Este juego no está activo', 'gana-con-colompro'));
        }
        
        // Si es el primer giro, marcar como jugando y asignar recompensa inicial
        if ($game->status === 'pending') {
            // Calcular recompensa inicial del 1%
            $order = wc_get_order($game->order_id);
            $initial_reward = $order->get_total() * 0.01; // 1% inicial
            
            GCC_Database::update_game($game_id, array(
                'status' => 'playing',
                'started_at' => current_time('mysql'),
                'current_level' => 1,
                'reward_percentage' => 1,
                'reward_amount' => $initial_reward
            ));
            
            // Actualizar el objeto game para reflejar los cambios
            $game = GCC_Database::get_game($game_id);
        }
        
        // Determinar nivel actual
        $current_level = intval($game->current_level);
        
        // Log para debug
        error_log('GCC spin - Game ID: ' . $game_id . ', Current Level: ' . $current_level . ', Status: ' . $game->status);
        
        // Verificar si ya llegó al máximo
        if ($current_level > 8) {
            return array('error' => __('Ya alcanzaste el nivel máximo', 'gana-con-colompro'));
        }
        
        // NO verificar duplicados si el último resultado fue "repeat"
        $last_spin = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gcc_spins 
            WHERE game_id = %d 
            ORDER BY id DESC 
            LIMIT 1",
            $game_id
        ));
        
        // Solo verificar duplicados si el último giro NO fue "repeat"
        if ($last_spin && $last_spin->result !== 'repeat') {
            $spins_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_spins 
                WHERE game_id = %d AND level = %d",
                $game_id,
                $current_level
            ));
            
            if ($spins_count > 0) {
                GCC_Security::log_security_event('duplicate_spin_attempt', array(
                    'game_id' => $game_id,
                    'current_level' => $current_level,
                    'last_result' => $last_spin->result
                ));
                return array('error' => __('Ya giraste en este nivel', 'gana-con-colompro'));
            }
        }
        
        // Añadir requerimiento del wpdb global
        global $wpdb;
        
        // Calcular resultado
        $result = self::calculate_result();
        
        // Registrar giro
        GCC_Database::record_spin($game_id, $current_level, $result);
        
        // Procesar resultado
        $response = array(
            'result' => $result,
            'level' => $current_level,
            'reward_percentage' => self::$levels[$current_level]
        );
        
        switch ($result) {
            case self::RESULT_WIN:
                // Avanzar al siguiente nivel
                $new_level = $current_level + 1;
                $reward_percentage = self::$levels[$new_level];
                
                // Si llegó al nivel 8, completar el juego
                if ($new_level === 8) {
                    GCC_Database::update_game($game_id, array(
                        'status' => 'completed',
                        'current_level' => $new_level,
                        'reward_percentage' => $reward_percentage,
                        'completed_at' => current_time('mysql')
                    ));
                    $response['game_completed'] = true;
                } else {
                    GCC_Database::update_game($game_id, array(
                        'current_level' => $new_level,
                        'reward_percentage' => $reward_percentage
                    ));
                }
                $response['level'] = $new_level; // Actualizar al nuevo nivel
                $response['reward_percentage'] = $reward_percentage;
                break;
                
            case self::RESULT_REPEAT:
                // Mantener el mismo nivel y permitir otro giro
                $response['reward_percentage'] = floatval($game->reward_percentage);
                // NO actualizamos nada en la BD para permitir otro giro
                break;
                
            case self::RESULT_LOSE:
                // Perder todo
                GCC_Database::update_game($game_id, array(
                    'status' => 'lost',
                    'current_level' => $current_level,
                    'reward_percentage' => 0,
                    'reward_amount' => 0,
                    'completed_at' => current_time('mysql')
                ));
                $response['game_over'] = true;
                $response['reward_percentage'] = 0;
                break;
        }
        
        // Calcular valor del premio en COP
        $order = wc_get_order($game->order_id);
        if ($order) {
            $order_total = $order->get_total();
            $response['reward_amount'] = $order_total * ($response['reward_percentage'] / 100);
        }
        
        return $response;
    }
    
    /**
     * Calcular resultado basado en probabilidades
     */
    private static function calculate_result() {
        // Obtener probabilidades de configuración
        $prob_win = intval(gcc_get_option('probability_win', 33));
        $prob_repeat = intval(gcc_get_option('probability_repeat', 34));
        $prob_lose = intval(gcc_get_option('probability_lose', 33));
        
        // Generar número aleatorio entre 1 y 100
        $random = mt_rand(1, 100);
        
        // Determinar resultado
        if ($random <= $prob_win) {
            return self::RESULT_WIN;
        } elseif ($random <= ($prob_win + $prob_repeat)) {
            return self::RESULT_REPEAT;
        } else {
            return self::RESULT_LOSE;
        }
    }
    
    /**
     * Reclamar premio
     */
    public static function claim_reward($game_id) {
        // Obtener juego
        $game = GCC_Database::get_game($game_id);
        if (!$game) {
            return array('error' => __('Juego no encontrado', 'gana-con-colompro'));
        }
        
        // Verificar que puede reclamar
        if ($game->status === 'lost') {
            return array('error' => __('No hay premio para reclamar porque perdiste', 'gana-con-colompro'));
        }
        
        if ($game->status === 'claimed') {
            return array('error' => __('Ya reclamaste tu premio', 'gana-con-colompro'));
        }
        
        // Si está pendiente, asignar el 1% inicial
        if ($game->status === 'pending') {
            $order = wc_get_order($game->order_id);
            if ($order) {
                $game->reward_percentage = 1;
                $game->reward_amount = $order->get_total() * 0.01;
            }
        }
        
        // Verificar que tiene premio
        if ($game->reward_percentage <= 0) {
            // Si está pendiente, tiene 1% garantizado
            if ($game->status === 'pending') {
                $game->reward_percentage = 1;
            } else {
                return array('error' => __('No hay premio para reclamar', 'gana-con-colompro'));
            }
        }
        
        // Calcular monto del premio
        $order = wc_get_order($game->order_id);
        if (!$order) {
            return array('error' => __('Orden no encontrada', 'gana-con-colompro'));
        }
        
        $order_total = $order->get_total();
        $reward_amount = $order_total * ($game->reward_percentage / 100);
        
        // Generar cupón
        $coupon_code = GCC_Security::generate_coupon_code();
        $coupon_manager = new GCC_Coupon_Manager();
        $wc_coupon_id = $coupon_manager->create_woocommerce_coupon(
            $coupon_code,
            $game->reward_percentage,
            $reward_amount,
            $order->get_user_id()
        );
        
        if (!$wc_coupon_id) {
            return array('error' => __('Error al crear el cupón', 'gana-con-colompro'));
        }
        
        // Fecha de expiración (60 días)
        $expires_days = intval(gcc_get_option('coupon_duration_days', 60));
        $expires_at = date('Y-m-d 23:59:59', strtotime("+{$expires_days} days"));
        
        // Guardar en base de datos
        GCC_Database::create_coupon(
            $game_id,
            $coupon_code,
            $game->reward_percentage,
            $reward_amount,
            $expires_at
        );
        
        // Actualizar juego
        GCC_Database::update_game($game_id, array(
            'status' => 'claimed',
            'coupon_code' => $coupon_code,
            'reward_amount' => $reward_amount,
            'completed_at' => current_time('mysql')
        ));
        
        // Enviar email con el cupón
        GCC_Email_Manager::send_reward_email($game_id, $coupon_code);
        
        return array(
            'success' => true,
            'coupon_code' => $coupon_code,
            'reward_percentage' => $game->reward_percentage,
            'reward_amount' => $reward_amount,
            'message' => gcc_get_option('reward_message', '¡Tenés 60 días para usar este bono! ¡Aprovechalo pues!')
        );
    }
    
    /**
     * Obtener estado del juego
     */
    public static function get_game_state($order_id) {
        $game = GCC_Database::get_game_by_order($order_id);
        
        if (!$game) {
            return null;
        }
        
        // Determinar el nivel visual correcto
        $current_level = intval($game->current_level);
        $reward_percentage = floatval($game->reward_percentage);
        
        // Si el juego está pendiente (nunca se ha jugado)
        if ($game->status === 'pending') {
            $current_level = 1; // Empezar en nivel 1
            $reward_percentage = 1; // 1% garantizado
        } else if ($game->status === 'playing' && $current_level == 0) {
            // Si está jugando pero el nivel es 0, significa que ya jugó al menos una vez
            $current_level = 1;
        }
        
        $state = array(
            'status' => $game->status,
            'current_level' => $current_level,
            'reward_percentage' => $reward_percentage,
            'can_play' => in_array($game->status, array('pending', 'playing')),
            'can_claim' => true // Siempre puede reclamar si hay premio
        );
        
        // Si está perdido, no puede reclamar
        if ($game->status === 'lost') {
            $state['can_claim'] = false;
        }
        
        // Obtener historial de giros
        $spins = GCC_Database::get_game_spins($game->id);
        $state['spins'] = array();
        
        foreach ($spins as $spin) {
            $state['spins'][] = array(
                'level' => intval($spin->level),
                'result' => $spin->result
            );
        }
        
        // Calcular valor del premio
        $order = wc_get_order($order_id);
        if ($order) {
            $state['reward_amount'] = $order->get_total() * ($reward_percentage / 100);
        }
        
        return $state;
    }
    
    /**
     * Obtener porcentaje de recompensa por nivel
     */
    public static function get_level_percentage($level) {
        return isset(self::$levels[$level]) ? self::$levels[$level] : 0;
    }
}