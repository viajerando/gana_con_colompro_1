<?php
/**
 * Gestor de cupones
 */
class GCC_Coupon_Manager {
    
    /**
     * Crear cupón en WooCommerce
     */
    public function create_woocommerce_coupon($code, $percentage, $amount, $user_id = null) {
        // Verificar que el código no existe
        $existing = new WC_Coupon($code);
        if ($existing->get_id()) {
            return false;
        }
        
        // Crear nuevo cupón
        $coupon = new WC_Coupon();
        
        // Configuración básica
        $coupon->set_code($code);
        $coupon->set_description(sprintf(
            __('Cupón del %s%% generado por Gana con Colompro', 'gana-con-colompro'),
            $percentage
        ));
        
        // Tipo y monto
        $coupon->set_discount_type('percent');
        $coupon->set_amount($percentage);
        
        // Restricciones
        $coupon->set_individual_use(true); // No acumulable
        $coupon->set_usage_limit(1); // Un solo uso
        $coupon->set_usage_limit_per_user(1);
        
        // Fecha de expiración
        $expires_days = intval(gcc_get_option('coupon_duration_days', 60));
        $expiry_date = date('Y-m-d', strtotime("+{$expires_days} days"));
        $coupon->set_date_expires($expiry_date);
        
        // Si hay usuario, restringir a ese usuario
        if ($user_id) {
            $coupon->set_email_restrictions(array($this->get_user_email($user_id)));
        }
        
        // Aplicable a todos los productos
        $coupon->set_excluded_product_ids(array());
        $coupon->set_excluded_product_categories(array());
        
        // Meta datos adicionales
        $coupon->add_meta_data('_gcc_generated', 'yes');
        $coupon->add_meta_data('_gcc_percentage', $percentage);
        $coupon->add_meta_data('_gcc_amount', $amount);
        
        // Guardar
        $coupon_id = $coupon->save();
        
        // Hook para permitir modificaciones adicionales
        do_action('gcc_after_coupon_created', $coupon_id, $code, $percentage, $amount);
        
        return $coupon_id;
    }
    
    /**
     * Obtener email del usuario
     */
    private function get_user_email($user_id) {
        $user = get_user_by('id', $user_id);
        return $user ? $user->user_email : '';
    }
    
    /**
     * Verificar si un cupón ha sido usado
     */
    public static function is_coupon_used($code) {
        $coupon = new WC_Coupon($code);
        
        if (!$coupon->get_id()) {
            return null;
        }
        
        return $coupon->get_usage_count() > 0;
    }
    
    /**
     * Obtener información del cupón
     */
    public static function get_coupon_info($code) {
        $coupon = new WC_Coupon($code);
        
        if (!$coupon->get_id()) {
            return null;
        }
        
        return array(
            'code' => $code,
            'amount' => $coupon->get_amount(),
            'discount_type' => $coupon->get_discount_type(),
            'expiry_date' => $coupon->get_date_expires(),
            'usage_count' => $coupon->get_usage_count(),
            'usage_limit' => $coupon->get_usage_limit(),
            'is_valid' => $coupon->is_valid()
        );
    }
    
    /**
     * Hook cuando se usa un cupón
     */
    public static function init_hooks() {
        add_action('woocommerce_applied_coupon', array(__CLASS__, 'on_coupon_applied'));
    }
    
    /**
     * Cuando se aplica un cupón
     */
    public static function on_coupon_applied($coupon_code) {
        // Verificar si es un cupón generado por nosotros
        $coupon = new WC_Coupon($coupon_code);
        
        if ($coupon->get_meta('_gcc_generated') !== 'yes') {
            return;
        }
        
        // Marcar como usado en nuestra base de datos
        GCC_Database::mark_coupon_used($coupon_code);
        
        // Log del evento
        GCC_Security::log_security_event('coupon_applied', array(
            'coupon_code' => $coupon_code,
            'user_id' => get_current_user_id()
        ));
    }
}

// Inicializar hooks
add_action('init', array('GCC_Coupon_Manager', 'init_hooks'));