<?php
/**
 * Clase para manejar operaciones de base de datos
 */
class GCC_Database {
    
    /**
     * Crear un nuevo juego
     */
    public static function create_game($order_id) {
        global $wpdb;
        
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }
        
        $user_id = $order->get_user_id();
        $user_email = $order->get_billing_email();
        
        $data = array(
            'order_id' => $order_id,
            'user_id' => $user_id ? $user_id : null,
            'user_email' => $user_email,
            'status' => 'pending',
            'current_level' => 0,
            'reward_percentage' => 0,
            'reward_amount' => 0
        );
        
        $wpdb->insert(
            $wpdb->prefix . 'gcc_games',
            $data,
            array('%d', '%d', '%s', '%s', '%d', '%f', '%f')
        );
        
        return $wpdb->insert_id;
    }
    
    /**
     * Obtener juego por order_id con caché
     */
    public static function get_game_by_order($order_id) {
        global $wpdb;
        
        // Intentar obtener de caché primero
        $cache_key = 'gcc_game_order_' . $order_id;
        $game = wp_cache_get($cache_key, 'gcc_games');
        
        // Si está en modo debug o es una solicitud AJAX, no usar caché
        if ((defined('WP_DEBUG') && WP_DEBUG) || wp_doing_ajax()) {
            $game = false;
        }
        
        if (false === $game) {
            $game = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gcc_games WHERE order_id = %d",
                $order_id
            ));
            
            if ($game) {
                wp_cache_set($cache_key, $game, 'gcc_games', 3600); // Cache por 1 hora
            }
        }
        
        return $game;
    }
    
    /**
     * Obtener juego por ID
     */
    public static function get_game($game_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gcc_games WHERE id = %d",
            $game_id
        ));
    }
    
    /**
     * Actualizar juego
     */
    public static function update_game($game_id, $data) {
        global $wpdb;
        
        // Log de debug
        error_log('GCC Database - Updating game ' . $game_id . ' with data: ' . print_r($data, true));
        
        $result = $wpdb->update(
            $wpdb->prefix . 'gcc_games',
            $data,
            array('id' => $game_id)
        );
        
        // Limpiar caché si existe
        $game = self::get_game($game_id);
        if ($game) {
            $cache_key = 'gcc_game_order_' . $game->order_id;
            wp_cache_delete($cache_key, 'gcc_games');
        }
        
        error_log('GCC Database - Update result: ' . ($result !== false ? 'success' : 'failed'));
        
        return $result;
    }
    
    /**
     * Registrar un giro
     */
    public static function record_spin($game_id, $level, $result) {
        global $wpdb;
        
        return $wpdb->insert(
            $wpdb->prefix . 'gcc_spins',
            array(
                'game_id' => $game_id,
                'level' => $level,
                'result' => $result
            ),
            array('%d', '%d', '%s')
        );
    }
    
    /**
     * Obtener giros de un juego
     */
    public static function get_game_spins($game_id) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gcc_spins WHERE game_id = %d ORDER BY id ASC",
            $game_id
        ));
    }
    
    /**
     * Crear cupón
     */
    public static function create_coupon($game_id, $coupon_code, $percentage, $amount, $expires_at) {
        global $wpdb;
        
        return $wpdb->insert(
            $wpdb->prefix . 'gcc_coupons',
            array(
                'game_id' => $game_id,
                'coupon_code' => $coupon_code,
                'percentage' => $percentage,
                'amount' => $amount,
                'expires_at' => $expires_at
            ),
            array('%d', '%s', '%f', '%f', '%s')
        );
    }
    
    /**
     * Obtener cupón por código
     */
    public static function get_coupon_by_code($coupon_code) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gcc_coupons WHERE coupon_code = %s",
            $coupon_code
        ));
    }
    
    /**
     * Marcar cupón como usado
     */
    public static function mark_coupon_used($coupon_code) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'gcc_coupons',
            array('used_at' => current_time('mysql')),
            array('coupon_code' => $coupon_code),
            array('%s'),
            array('%s')
        );
    }
    
    /**
     * Obtener cupones pendientes de recordatorio
     */
    public static function get_pending_reminders($days_before_expiry) {
        global $wpdb;
        
        $reminder_field = 'reminder_' . $days_before_expiry;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, g.user_email, g.order_id 
            FROM {$wpdb->prefix}gcc_coupons c
            JOIN {$wpdb->prefix}gcc_games g ON c.game_id = g.id
            WHERE c.used_at IS NULL 
            AND c.$reminder_field = 0
            AND DATE(c.expires_at) = DATE(DATE_ADD(NOW(), INTERVAL %d DAY))",
            $days_before_expiry
        ));
    }
    
    /**
     * Marcar recordatorio como enviado
     */
    public static function mark_reminder_sent($coupon_id, $days) {
        global $wpdb;
        
        $reminder_field = 'reminder_' . $days;
        
        return $wpdb->update(
            $wpdb->prefix . 'gcc_coupons',
            array($reminder_field => 1),
            array('id' => $coupon_id),
            array('%d'),
            array('%d')
        );
    }
    
    /**
     * Obtener estadísticas generales
     */
    public static function get_statistics() {
        global $wpdb;
        
        $stats = array();
        
        // Total de juegos
        $stats['total_games'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games WHERE status != 'pending'"
        );
        
        // Total de juegos completados
        $stats['completed_games'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games WHERE status = 'completed'"
        );
        
        // Total de cupones generados
        $stats['total_coupons'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons"
        );
        
        // Total de cupones usados
        $stats['used_coupons'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gcc_coupons WHERE used_at IS NOT NULL"
        );
        
        // Valor total de bonos
        $stats['total_bonus_value'] = $wpdb->get_var(
            "SELECT SUM(amount) FROM {$wpdb->prefix}gcc_coupons"
        );
        
        // Estadísticas de resultados
        $results = $wpdb->get_results(
            "SELECT result, COUNT(*) as count 
            FROM {$wpdb->prefix}gcc_spins 
            GROUP BY result"
        );
        
        $stats['results'] = array();
        foreach ($results as $result) {
            $stats['results'][$result->result] = $result->count;
        }
        
        return $stats;
    }
    
    /**
     * Obtener juegos con paginación
     */
    public static function get_games($page = 1, $per_page = 20) {
        global $wpdb;
        
        $offset = ($page - 1) * $per_page;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT g.*, c.coupon_code, c.used_at
            FROM {$wpdb->prefix}gcc_games g
            LEFT JOIN {$wpdb->prefix}gcc_coupons c ON g.id = c.game_id
            ORDER BY g.created_at DESC
            LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ));
    }
    
    /**
     * Contar total de juegos
     */
    public static function count_games() {
        global $wpdb;
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}gcc_games");
    }
}