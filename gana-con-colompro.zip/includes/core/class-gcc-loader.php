<?php
/**
 * Clase principal del loader
 */
class GCC_Loader {
    
    /**
     * Instancia del loader
     */
    protected static $instance = null;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->load_dependencies();
        $this->define_hooks();
    }
    
    /**
     * Cargar dependencias
     */
    private function load_dependencies() {
        // Core
        require_once GCC_PLUGIN_DIR . 'includes/core/class-gcc-database.php';
        require_once GCC_PLUGIN_DIR . 'includes/core/class-gcc-security.php';
        
        // Game
        require_once GCC_PLUGIN_DIR . 'includes/game/class-gcc-game-engine.php';
        require_once GCC_PLUGIN_DIR . 'includes/game/class-gcc-game-controller.php';
        require_once GCC_PLUGIN_DIR . 'includes/game/class-gcc-coupon-manager.php';
        
        // Email
        require_once GCC_PLUGIN_DIR . 'includes/email/class-gcc-email-manager.php';
        require_once GCC_PLUGIN_DIR . 'includes/email/class-gcc-email-templates.php';
        
        // Admin
        if (is_admin()) {
            require_once GCC_PLUGIN_DIR . 'includes/admin/class-gcc-admin.php';
            require_once GCC_PLUGIN_DIR . 'includes/admin/class-gcc-statistics.php';
            require_once GCC_PLUGIN_DIR . 'includes/admin/class-gcc-settings.php';
        }
    }
    
    /**
     * Definir hooks
     */
    private function define_hooks() {
        // Hooks de WooCommerce para preparar el juego
        add_action('woocommerce_payment_complete', array($this, 'on_payment_complete'));
        add_action('woocommerce_order_status_completed', array($this, 'on_order_completed'));
        add_action('woocommerce_order_status_processing', array($this, 'on_order_processing'));
        
        // Hook para mostrar en la página de agradecimiento
        // Usamos prioridad 5 para ejecutar antes que el detalle del pedido
        add_action('woocommerce_thankyou', array($this, 'show_game_invitation'), 5);
        
        // Hook para verificar solicitudes del juego
        add_action('template_redirect', array($this, 'check_game_request'));
        
        // AJAX handlers - Asegurar que están disponibles para usuarios no logueados
        add_action('wp_ajax_gcc_spin_wheel', array('GCC_Game_Controller', 'ajax_spin_wheel'));
        add_action('wp_ajax_nopriv_gcc_spin_wheel', array('GCC_Game_Controller', 'ajax_spin_wheel'));
        add_action('wp_ajax_gcc_claim_reward', array('GCC_Game_Controller', 'ajax_claim_reward'));
        add_action('wp_ajax_nopriv_gcc_claim_reward', array('GCC_Game_Controller', 'ajax_claim_reward'));
        
        // Cargar scripts cuando sea necesario
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Programar email de invitación
        add_action('gcc_send_invitation', array('GCC_Email_Manager', 'send_invitation_email'));
        
        // Cron jobs
        add_action('gcc_check_reminders', array('GCC_Email_Manager', 'send_reminders'));
        
        // Admin
        if (is_admin()) {
            new GCC_Admin();
            new GCC_Settings();
        }
    }
    
    /**
     * Ejecutar el loader
     */
    public function run() {
        // Programar cron job para recordatorios
        if (!wp_next_scheduled('gcc_check_reminders')) {
            wp_schedule_event(time(), 'daily', 'gcc_check_reminders');
        }
    }
    
    /**
     * Cuando se completa el pago
     */
    public function on_payment_complete($order_id) {
        $this->prepare_game_for_order($order_id);
    }
    
    /**
     * Cuando la orden está completada
     */
    public function on_order_completed($order_id) {
        $this->prepare_game_for_order($order_id);
    }
    
    /**
     * Cuando la orden está en proceso
     */
    public function on_order_processing($order_id) {
        $this->prepare_game_for_order($order_id);
    }
    
    /**
     * Preparar juego para una orden
     */
    private function prepare_game_for_order($order_id) {
        // Verificar si ya existe un juego para esta orden
        if (get_post_meta($order_id, '_gcc_game_token', true)) {
            return;
        }
        
        // Generar token único
        $token = GCC_Security::generate_token($order_id);
        update_post_meta($order_id, '_gcc_game_token', $token);
        
        // Crear registro en la base de datos
        GCC_Database::create_game($order_id);
        
        // Programar email de invitación (1 hora después)
        $delay_hours = intval(gcc_get_option('invitation_delay_hours', 1));
        wp_schedule_single_event(time() + ($delay_hours * 3600), 'gcc_send_invitation', array($order_id));
    }
    
    /**
     * Mostrar invitación al juego en la página de agradecimiento
     */
    public function show_game_invitation($order_id) {
        if (!$order_id) {
            return;
        }
        
        // Verificar configuración
        if (!gcc_get_option('show_game_on_thankyou', true)) {
            return;
        }
        
        // Verificar que el pedido existe
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        // Verificar el estado del pedido
        $valid_statuses = array('processing', 'completed');
        if (!in_array($order->get_status(), $valid_statuses)) {
            return;
        }
        
        // Preparar el juego si no existe
        $this->prepare_game_for_order($order_id);
        
        // Obtener el token del juego
        $token = get_post_meta($order_id, '_gcc_game_token', true);
        if (!$token) {
            return;
        }
        
        // Verificar si ya jugó
        $game = GCC_Database::get_game_by_order($order_id);
        if ($game && in_array($game->status, array('completed', 'claimed', 'lost'))) {
            // Ya jugó, mostrar mensaje
            ?>
            <div class="gcc-thankyou-message">
                <h2><?php _e('¡Gracias por tu compra!', 'gana-con-colompro'); ?></h2>
                <p><?php _e('Ya has jugado tu ruleta de la suerte para este pedido.', 'gana-con-colompro'); ?></p>
                <?php if ($game->coupon_code) : ?>
                    <p><?php printf(__('Tu código de cupón es: <strong>%s</strong>', 'gana-con-colompro'), $game->coupon_code); ?></p>
                <?php endif; ?>
            </div>
            <?php
            return;
        }
        
        // Mostrar botón para jugar
        $game_url = gcc_get_game_url($order_id, $token);
        ?>
        <div class="gcc-thankyou-game">
            <div class="gcc-game-invitation">
                <h2><?php _e('🎯 ¡Tenés una Ruleta de la Suerte esperándote!', 'gana-con-colompro'); ?></h2>
                <p><?php _e('Como agradecimiento por tu compra, podés jugar nuestra ruleta y ganar hasta un <strong>100% de descuento</strong> en tu próxima compra.', 'gana-con-colompro'); ?></p>
                
                <div class="gcc-game-benefits">
                    <ul>
                        <li><?php _e('🎁 Empezás con 1% de descuento garantizado', 'gana-con-colompro'); ?></li>
                        <li><?php _e('🎰 Podés llegar hasta 100% de descuento', 'gana-con-colompro'); ?></li>
                        <li><?php _e('⏱️ Solo toma 1 minuto jugar', 'gana-con-colompro'); ?></li>
                    </ul>
                </div>
                
                <div class="gcc-game-actions">
                    <a href="<?php echo esc_url($game_url); ?>" class="button gcc-play-button" target="_blank">
                        <?php _e('🎮 ¡Jugar Ahora!', 'gana-con-colompro'); ?>
                    </a>
                    <p class="gcc-game-note"><?php _e('También te enviamos el enlace por email por si querés jugar más tarde.', 'gana-con-colompro'); ?></p>
                </div>
            </div>
        </div>
        
        <style>
            .gcc-thankyou-game {
                margin: 30px 0;
                padding: 30px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 10px;
                color: white;
                text-align: center;
            }
            
            .gcc-game-invitation h2 {
                color: white;
                margin-bottom: 20px;
                font-size: 28px;
            }
            
            .gcc-game-invitation p {
                font-size: 18px;
                margin-bottom: 25px;
                color: white;
            }
            
            .gcc-game-invitation strong {
                color: #FFD700;
                font-size: 120%;
            }
            
            .gcc-game-benefits {
                background: rgba(255,255,255,0.1);
                border-radius: 8px;
                padding: 20px;
                margin: 20px auto;
                max-width: 500px;
            }
            
            .gcc-game-benefits ul {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            
            .gcc-game-benefits li {
                padding: 10px 0;
                font-size: 16px;
            }
            
            .gcc-play-button {
                display: inline-block;
                background: #FFD700;
                color: #333 !important;
                padding: 20px 50px !important;
                font-size: 24px !important;
                font-weight: bold;
                text-decoration: none;
                border-radius: 50px !important;
                transition: all 0.3s ease;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                border: none;
                cursor: pointer;
            }
            
            .gcc-play-button:hover {
                background: #FFC700 !important;
                transform: translateY(-3px);
                box-shadow: 0 8px 20px rgba(0,0,0,0.4);
                color: #333 !important;
            }
            
            .gcc-game-note {
                margin-top: 15px;
                font-size: 14px;
                opacity: 0.9;
            }
            
            .gcc-thankyou-message {
                margin: 30px 0;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 8px;
                text-align: center;
            }
            
            @media (max-width: 600px) {
                .gcc-thankyou-game {
                    padding: 20px;
                }
                
                .gcc-game-invitation h2 {
                    font-size: 22px;
                }
                
                .gcc-play-button {
                    padding: 15px 30px !important;
                    font-size: 20px !important;
                }
            }
        </style>
        <?php
    }
    
    /**
     * Verificar si hay una solicitud de juego
     */
    public function check_game_request() {
        if (!isset($_GET['gcc_game']) || !isset($_GET['order']) || !isset($_GET['token'])) {
            return;
        }
        
        $order_id = intval($_GET['order']);
        $token = sanitize_text_field($_GET['token']);
        
        // Verificar token
        if (!GCC_Security::verify_token($order_id, $token)) {
            wp_die(__('Token inválido o expirado.', 'gana-con-colompro'));
        }
        
        // Cargar template del juego
        include GCC_PLUGIN_DIR . 'templates/game.php';
        exit;
    }
    
    /**
     * Cargar scripts y estilos
     */
    public function enqueue_scripts() {
        // Solo cargar en la página del juego
        if (isset($_GET['gcc_game'])) {
            // CSS
            wp_enqueue_style('gcc-game', GCC_PLUGIN_URL . 'assets/css/game.css', array(), GCC_VERSION);
            
            // JS
            wp_enqueue_script('gcc-game', GCC_PLUGIN_URL . 'assets/js/game.js', array('jquery'), GCC_VERSION, true);
            
            // Localización
            $order_id = isset($_GET['order']) ? intval($_GET['order']) : 0;
            $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
            
            wp_localize_script('gcc-game', 'gcc_ajax', array(
                'url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('gcc_game_nonce'),
                'order_id' => $order_id,
                'token' => $token,
                'debug' => defined('WP_DEBUG') && WP_DEBUG
            ));
        }
        
        // Cargar estilos en la página de thank you también
        if (is_wc_endpoint_url('order-received')) {
            wp_enqueue_style('gcc-thankyou', GCC_PLUGIN_URL . 'assets/css/game.css', array(), GCC_VERSION);
        }
    }
    
    /**
     * Obtener instancia
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}