<?php
/**
 * Clase de desactivación del plugin
 */
class GCC_Deactivator {
    
    /**
     * Desactivar el plugin
     */
    public static function deactivate() {
        // Limpiar eventos cron
        wp_clear_scheduled_hook('gcc_check_reminders');
        
        // Limpiar todos los eventos programados individuales
        self::clear_scheduled_events();
        
        // Limpiar caché
        self::clear_cache();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Limpiar eventos programados
     */
    private static function clear_scheduled_events() {
        // Obtener todos los cron jobs
        $crons = _get_cron_array();
        
        if (empty($crons)) {
            return;
        }
        
        foreach ($crons as $timestamp => $cron) {
            foreach ($cron as $hook => $args) {
                // Eliminar solo eventos de nuestro plugin
                if (strpos($hook, 'gcc_') === 0) {
                    foreach ($args as $arg) {
                        wp_unschedule_event($timestamp, $hook, $arg['args']);
                    }
                }
            }
        }
    }
    
    /**
     * Limpiar caché relacionado con el plugin
     */
    private static function clear_cache() {
        // Limpiar caché de objetos
        wp_cache_delete_group('gcc_games');
        
        // Limpiar transients
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_gcc_%' 
            OR option_name LIKE '_transient_timeout_gcc_%'"
        );
    }
}