<?php
/**
 * Clase de activación del plugin
 */
class GCC_Activator {
    
    /**
     * Activar el plugin
     */
    public static function activate() {
        // Crear tablas de base de datos
        self::create_tables();
        
        // Crear opciones por defecto
        self::create_default_options();
        
        // Programar eventos cron
        if (!wp_next_scheduled('gcc_check_reminders')) {
            wp_schedule_event(time(), 'daily', 'gcc_check_reminders');
        }
        
        // Crear capacidades de usuario
        self::create_capabilities();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Crear tablas de base de datos
     */
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tabla de juegos
        $table_games = $wpdb->prefix . 'gcc_games';
        $sql_games = "CREATE TABLE $table_games (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            user_email varchar(100) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            current_level int(11) DEFAULT 0,
            spins_data longtext DEFAULT NULL,
            reward_percentage decimal(5,2) DEFAULT 0,
            reward_amount decimal(10,2) DEFAULT 0,
            coupon_code varchar(50) DEFAULT NULL,
            started_at datetime DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY order_id_unique (order_id),
            KEY user_id (user_id),
            KEY user_email (user_email),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Tabla de giros
        $table_spins = $wpdb->prefix . 'gcc_spins';
        $sql_spins = "CREATE TABLE $table_spins (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            game_id bigint(20) NOT NULL,
            level int(11) NOT NULL,
            result varchar(20) NOT NULL,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY game_id (game_id),
            KEY timestamp (timestamp)
        ) $charset_collate;";
        
        // Tabla de cupones
        $table_coupons = $wpdb->prefix . 'gcc_coupons';
        $sql_coupons = "CREATE TABLE $table_coupons (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            game_id bigint(20) NOT NULL,
            coupon_code varchar(50) NOT NULL,
            percentage decimal(5,2) NOT NULL,
            amount decimal(10,2) NOT NULL,
            expires_at datetime NOT NULL,
            used_at datetime DEFAULT NULL,
            reminder_30 tinyint(1) DEFAULT 0,
            reminder_15 tinyint(1) DEFAULT 0,
            reminder_7 tinyint(1) DEFAULT 0,
            reminder_3 tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY coupon_code_unique (coupon_code),
            KEY game_id (game_id),
            KEY expires_at (expires_at),
            KEY used_at (used_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_games);
        dbDelta($sql_spins);
        dbDelta($sql_coupons);
        
        // Guardar versión de la base de datos
        update_option('gcc_db_version', '1.0.0');
    }
    
    /**
     * Crear opciones por defecto
     */
    private static function create_default_options() {
        $default_options = array(
            // Probabilidades
            'probability_win' => 33,
            'probability_repeat' => 34,
            'probability_lose' => 33,
            
            // Colores
            'color_win' => '#28a745',
            'color_repeat' => '#007bff',
            'color_lose' => '#dc3545',
            
            // Configuración del juego
            'show_game_on_thankyou' => true,
            'coupon_duration_days' => 60,
            'invitation_delay_hours' => 1,
            'enable_sounds' => true,
            
            // Textos
            'game_title' => 'Gana con Colompro',
            'reward_message' => '¡Tenés 60 días para usar este bono! ¡Aprovechalo pues!',
            
            // Email
            'enable_reminders' => true,
            'reminder_days' => array(30, 15, 7, 3),
            
            // Datos
            'remove_data_on_uninstall' => false
        );
        
        // Solo crear si no existen
        if (!get_option('gcc_settings')) {
            update_option('gcc_settings', $default_options);
        }
    }
    
    /**
     * Crear capacidades de usuario
     */
    private static function create_capabilities() {
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap('manage_gcc_games');
            $role->add_cap('view_gcc_statistics');
            $role->add_cap('edit_gcc_settings');
        }
    }
}