<?php
/**
 * Clase de seguridad
 */
class GCC_Security {
    
    /**
     * Generar token único para un pedido
     */
    public static function generate_token($order_id) {
        $secret = wp_salt('auth');
        $data = array(
            'order_id' => $order_id,
            'time' => time(),
            'rand' => wp_rand(100000, 999999),
            'user_ip' => self::get_client_ip()
        );
        return wp_hash(json_encode($data) . $secret);
    }
    
    /**
     * Verificar token
     */
    public static function verify_token($order_id, $token) {
        $stored_token = get_post_meta($order_id, '_gcc_game_token', true);
        
        if (!$stored_token || $stored_token !== $token) {
            return false;
        }
        
        // Verificar que el pedido existe y está pagado
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }
        
        // Verificar estado del pedido
        $valid_statuses = array('processing', 'completed');
        if (!in_array($order->get_status(), $valid_statuses)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Verificar nonce AJAX
     */
    public static function verify_ajax_nonce() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gcc_game_nonce')) {
            wp_die(__('Error de seguridad', 'gana-con-colompro'));
        }
    }
    
    /**
     * Sanitizar datos del juego
     */
    public static function sanitize_game_data($data) {
        $sanitized = array();
        
        if (isset($data['order_id'])) {
            $sanitized['order_id'] = intval($data['order_id']);
        }
        
        if (isset($data['token'])) {
            $sanitized['token'] = sanitize_text_field($data['token']);
        }
        
        if (isset($data['level'])) {
            $sanitized['level'] = intval($data['level']);
        }
        
        if (isset($data['action'])) {
            $sanitized['action'] = sanitize_text_field($data['action']);
        }
        
        return $sanitized;
    }
    
    /**
     * Verificar si el juego puede continuar
     */
    public static function can_play_game($order_id) {
        // Obtener juego de la base de datos
        $game = GCC_Database::get_game_by_order($order_id);
        
        if (!$game) {
            return array('error' => __('Juego no encontrado', 'gana-con-colompro'));
        }
        
        // Verificar estado del juego
        if ($game->status === 'completed') {
            return array('error' => __('Este juego ya fue completado', 'gana-con-colompro'));
        }
        
        if ($game->status === 'lost') {
            return array('error' => __('Lo sentimos, perdiste en este juego', 'gana-con-colompro'));
        }
        
        if ($game->status === 'claimed') {
            return array('error' => __('Ya reclamaste tu premio', 'gana-con-colompro'));
        }
        
        return true;
    }
    
    /**
     * Log de seguridad
     */
    public static function log_security_event($event_type, $details = array()) {
        if (!WP_DEBUG_LOG) {
            return;
        }
        
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'event_type' => $event_type,
            'ip_address' => self::get_client_ip(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'details' => $details
        );
        
        error_log('GCC Security Event: ' . json_encode($log_entry));
    }
    
    /**
     * Obtener IP del cliente
     */
    private static function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key])) {
                $ip = filter_var($_SERVER[$key], FILTER_VALIDATE_IP);
                if ($ip !== false) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
    
    /**
     * Validar probabilidades
     */
    public static function validate_probabilities($win, $repeat, $lose) {
        $total = $win + $repeat + $lose;
        
        // Permitir un margen de error pequeño por redondeo
        if (abs($total - 100) > 0.01) {
            return false;
        }
        
        // Verificar que todas sean positivas
        if ($win < 0 || $repeat < 0 || $lose < 0) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Generar código de cupón único
     */
    public static function generate_coupon_code() {
        $prefix = 'GCC';
        $random = strtoupper(wp_generate_password(8, false, false));
        return $prefix . $random;
    }
}