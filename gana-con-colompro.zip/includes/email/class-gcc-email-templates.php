<?php
/**
 * Plantillas de email
 */
class GCC_Email_Templates {
    
    /**
     * Obtener header del email
     */
    private function get_header() {
        $logo_url = get_option('woocommerce_email_header_image');
        $bg_color = get_option('woocommerce_email_background_color', '#f7f7f7');
        $base_color = get_option('woocommerce_email_base_color', '#557da2');
        
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo get_bloginfo('name'); ?></title>
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background-color: <?php echo esc_attr($bg_color); ?>;
                    font-family: Arial, sans-serif;
                }
                .wrapper {
                    width: 100%;
                    background-color: <?php echo esc_attr($bg_color); ?>;
                    padding: 20px 0;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #ffffff;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .header {
                    background-color: <?php echo esc_attr($base_color); ?>;
                    padding: 30px;
                    text-align: center;
                }
                .header img {
                    max-width: 200px;
                    height: auto;
                }
                .content {
                    padding: 40px 30px;
                }
                .button {
                    display: inline-block;
                    background-color: <?php echo esc_attr($base_color); ?>;
                    color: #ffffff;
                    text-decoration: none;
                    padding: 15px 30px;
                    border-radius: 5px;
                    font-weight: bold;
                    margin: 20px 0;
                }
                .button:hover {
                    opacity: 0.9;
                }
                .footer {
                    background-color: #f8f8f8;
                    padding: 20px 30px;
                    text-align: center;
                    font-size: 12px;
                    color: #666666;
                }
                .coupon-box {
                    background-color: #f0f8ff;
                    border: 2px dashed <?php echo esc_attr($base_color); ?>;
                    padding: 20px;
                    margin: 20px 0;
                    text-align: center;
                    border-radius: 8px;
                }
                .coupon-code {
                    font-size: 28px;
                    font-weight: bold;
                    color: <?php echo esc_attr($base_color); ?>;
                    margin: 10px 0;
                    letter-spacing: 2px;
                }
                .highlight {
                    color: <?php echo esc_attr($base_color); ?>;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <div class="wrapper">
                <div class="container">
                    <div class="header">
                        <?php if ($logo_url) : ?>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
                        <?php else : ?>
                            <h1 style="color: #ffffff; margin: 0;"><?php echo esc_html(get_bloginfo('name')); ?></h1>
                        <?php endif; ?>
                    </div>
                    <div class="content">
        <?php
        return ob_get_clean();
    }
    
    /**
     * Obtener footer del email
     */
    private function get_footer() {
        ob_start();
        ?>
                    </div>
                    <div class="footer">
                        <p><?php echo sprintf(__('© %s %s. Todos los derechos reservados.', 'gana-con-colompro'), date('Y'), get_bloginfo('name')); ?></p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Template de invitación
     */
    public function get_invitation_template($args) {
        $content = $this->get_header();
        
        $content .= sprintf(
            '<h2>¡Hola %s!</h2>
            <p>¡Gracias por tu compra! Como agradecimiento especial, te invitamos a jugar nuestra <strong>Ruleta de la Suerte</strong> donde podrás ganar hasta un <span class="highlight">100%% de descuento</span> en tu próxima compra.</p>
            
            <p style="text-align: center;">
                <a href="%s" class="button">🎯 ¡JUGAR AHORA!</a>
            </p>
            
            <p><strong>¿Cómo funciona?</strong></p>
            <ul>
                <li>Empezás en el Nivel 1 con un 1%% de descuento garantizado</li>
                <li>En cada giro podés: ganar y avanzar, repetir el nivel, o perder todo</li>
                <li>¡Podés llegar hasta el Nivel 8 y ganar un 100%% de descuento!</li>
                <li>En cualquier momento podés parar y reclamar tu premio acumulado</li>
            </ul>
            
            <p><em>Este enlace es único para tu pedido #%s y solo puede ser usado una vez.</em></p>
            
            <p>¡No pierdas esta oportunidad!</p>',
            esc_html($args['customer_name']),
            esc_url($args['game_url']),
            esc_html($args['order_id'])
        );
        
        $content .= $this->get_footer();
        
        return $content;
    }
    
    /**
     * Template de premio
     */
    public function get_reward_template($args) {
        $content = $this->get_header();
        
        $content .= sprintf(
            '<h2>¡Felicitaciones %s! 🎉</h2>
            <p>¡Has ganado un increíble <span class="highlight">%s%% de descuento</span> (equivalente a %s) en nuestra Ruleta de la Suerte!</p>
            
            <div class="coupon-box">
                <p>Tu código de cupón es:</p>
                <div class="coupon-code">%s</div>
                <p style="margin-top: 15px; font-style: italic;">%s</p>
            </div>
            
            <p style="text-align: center;">
                <a href="%s" class="button">🛒 USAR MI CUPÓN</a>
            </p>
            
            <p><strong>Importante:</strong></p>
            <ul>
                <li>Este cupón es válido por 60 días</li>
                <li>Es de un solo uso y no es acumulable con otros cupones</li>
                <li>Se aplicará automáticamente al ingresar el código en el carrito</li>
            </ul>
            
            <p>¡Gracias por jugar y mucha suerte en tus compras!</p>',
            esc_html($args['customer_name']),
            esc_html($args['reward_percentage']),
            $args['reward_amount'],
            esc_html($args['coupon_code']),
            esc_html($args['message']),
            wc_get_page_permalink('shop')
        );
        
        $content .= $this->get_footer();
        
        return $content;
    }
    
    /**
     * Template de recordatorio
     */
    public function get_reminder_template($args) {
        $content = $this->get_header();
        
        // Mensaje según días restantes
        $urgency = '';
        if ($args['days_remaining'] <= 3) {
            $urgency = '🔥 <strong>¡ÚLTIMA OPORTUNIDAD!</strong> ';
        } elseif ($args['days_remaining'] <= 7) {
            $urgency = '⚠️ <strong>¡Atención!</strong> ';
        }
        
        $content .= sprintf(
            '<h2>Hola %s</h2>
            <p>%sTu cupón de descuento del <span class="highlight">%s%%</span> (equivalente a %s) está por expirar en <strong>%s días</strong>.</p>
            
            <div class="coupon-box">
                <p>Tu código de cupón es:</p>
                <div class="coupon-code">%s</div>
                <p style="margin-top: 10px;">¡No dejes pasar este descuento!</p>
            </div>
            
            <p style="text-align: center;">
                <a href="%s" class="button">🛒 COMPRAR AHORA</a>
            </p>
            
            <p>Recordá que este cupón:</p>
            <ul>
                <li>Es de un solo uso</li>
                <li>No es acumulable con otros descuentos</li>
                <li>Expira en %s días</li>
            </ul>
            
            <p><em>No queremos que pierdas este beneficio que ganaste. ¡Aprovechalo!</em></p>',
            esc_html($args['customer_name']),
            $urgency,
            esc_html($args['reward_percentage']),
            $args['reward_amount'],
            esc_html($args['days_remaining']),
            esc_html($args['coupon_code']),
            esc_url($args['shop_url']),
            esc_html($args['days_remaining'])
        );
        
        $content .= $this->get_footer();
        
        return $content;
    }
}