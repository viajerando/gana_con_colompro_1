<?php
/**
 * Gestor de correos electrónicos
 */
class GCC_Email_Manager {
    
    /**
     * Enviar email de invitación
     */
    public static function send_invitation_email($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }
        
        // Verificar si ya jugó
        $game = GCC_Database::get_game_by_order($order_id);
        if ($game && $game->status !== 'pending') {
            return false;
        }
        
        // Obtener datos
        $to = $order->get_billing_email();
        $customer_name = $order->get_billing_first_name();
        $game_url = gcc_get_game_url($order_id);
        
        if (!$game_url) {
            return false;
        }
        
        // Asunto
        $subject = __('🎯 ¡Tu ruleta de la suerte te espera en Colompro!', 'gana-con-colompro');
        
        // Obtener template
        $template = new GCC_Email_Templates();
        $body = $template->get_invitation_template(array(
            'customer_name' => $customer_name,
            'game_url' => $game_url,
            'order_id' => $order_id
        ));
        
        // Enviar
        return self::send_email($to, $subject, $body);
    }
    
    /**
     * Enviar email con cupón
     */
    public static function send_reward_email($game_id, $coupon_code) {
        $game = GCC_Database::get_game($game_id);
        if (!$game) {
            return false;
        }
        
        $order = wc_get_order($game->order_id);
        if (!$order) {
            return false;
        }
        
        // Obtener datos
        $to = $game->user_email;
        $customer_name = $order->get_billing_first_name();
        $reward_percentage = $game->reward_percentage;
        $reward_amount = wc_price($game->reward_amount);
        
        // Asunto
        $subject = sprintf(
            __('🎉 ¡Ganaste un %s%% de descuento en Colompro!', 'gana-con-colompro'),
            $reward_percentage
        );
        
        // Obtener template
        $template = new GCC_Email_Templates();
        $body = $template->get_reward_template(array(
            'customer_name' => $customer_name,
            'coupon_code' => $coupon_code,
            'reward_percentage' => $reward_percentage,
            'reward_amount' => $reward_amount,
            'message' => gcc_get_option('reward_message', '¡Tenés 60 días para usar este bono! ¡Aprovechalo pues!')
        ));
        
        // Enviar
        return self::send_email($to, $subject, $body);
    }
    
    /**
     * Enviar recordatorios
     */
    public static function send_reminders() {
        $reminder_days = gcc_get_option('reminder_days', array(30, 15, 7, 3));
        
        foreach ($reminder_days as $days) {
            $coupons = GCC_Database::get_pending_reminders($days);
            
            foreach ($coupons as $coupon) {
                self::send_reminder_email($coupon, $days);
                GCC_Database::mark_reminder_sent($coupon->id, $days);
            }
        }
    }
    
    /**
     * Enviar email de recordatorio
     */
    private static function send_reminder_email($coupon, $days_before) {
        $order = wc_get_order($coupon->order_id);
        if (!$order) {
            return false;
        }
        
        // Verificar si el cupón ya fue usado
        if (GCC_Coupon_Manager::is_coupon_used($coupon->coupon_code)) {
            return false;
        }
        
        // Datos
        $to = $coupon->user_email;
        $customer_name = $order->get_billing_first_name();
        
        // Asunto según días restantes
        if ($days_before >= 30) {
            $subject = __('⏰ Tu cupón de descuento expira en 30 días', 'gana-con-colompro');
        } elseif ($days_before >= 15) {
            $subject = __('⚠️ Tu cupón expira en 15 días - ¡No lo pierdas!', 'gana-con-colompro');
        } elseif ($days_before >= 7) {
            $subject = __('🚨 ¡Solo 7 días! Tu cupón está por expirar', 'gana-con-colompro');
        } else {
            $subject = __('🔥 ¡ÚLTIMO AVISO! Tu cupón expira en 3 días', 'gana-con-colompro');
        }
        
        // Template
        $template = new GCC_Email_Templates();
        $body = $template->get_reminder_template(array(
            'customer_name' => $customer_name,
            'coupon_code' => $coupon->coupon_code,
            'days_remaining' => $days_before,
            'reward_percentage' => $coupon->percentage,
            'reward_amount' => wc_price($coupon->amount),
            'shop_url' => wc_get_page_permalink('shop')
        ));
        
        return self::send_email($to, $subject, $body);
    }
    
    /**
     * Enviar email genérico
     */
    private static function send_email($to, $subject, $body) {
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
        );
        
        // Aplicar filtros de WooCommerce
        add_filter('wp_mail_from', array(__CLASS__, 'get_from_address'));
        add_filter('wp_mail_from_name', array(__CLASS__, 'get_from_name'));
        
        $sent = wp_mail($to, $subject, $body, $headers);
        
        // Remover filtros
        remove_filter('wp_mail_from', array(__CLASS__, 'get_from_address'));
        remove_filter('wp_mail_from_name', array(__CLASS__, 'get_from_name'));
        
        return $sent;
    }
    
    /**
     * Obtener dirección de origen
     */
    public static function get_from_address() {
        $from_address = get_option('woocommerce_email_from_address');
        return $from_address ? $from_address : get_option('admin_email');
    }
    
    /**
     * Obtener nombre de origen
     */
    public static function get_from_name() {
        $from_name = get_option('woocommerce_email_from_name');
        return $from_name ? $from_name : get_bloginfo('name');
    }
    
    /**
     * Programar email de invitación
     */
    public static function schedule_invitation($order_id) {
        $delay_hours = intval(gcc_get_option('invitation_delay_hours', 1));
        $timestamp = time() + ($delay_hours * 3600);
        
        wp_schedule_single_event($timestamp, 'gcc_send_invitation', array($order_id));
    }
}

// Hook para enviar invitación programada
add_action('gcc_send_invitation', array('GCC_Email_Manager', 'send_invitation_email'));