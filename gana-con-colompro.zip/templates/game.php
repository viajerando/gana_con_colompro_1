<?php
// Verificación mejorada al inicio del template
if (!isset($_GET['order']) || !isset($_GET['token'])) {
    wp_die(__('Parámetros inválidos', 'gana-con-colompro'));
}

$order_id = intval($_GET['order']);
$token = sanitize_text_field($_GET['token']);

// Verificar token
if (!GCC_Security::verify_token($order_id, $token)) {
    wp_die(__('Token inválido o expirado', 'gana-con-colompro'));
}

// Verificar orden
$order = wc_get_order($order_id);
if (!$order) {
    wp_die(__('Orden no encontrada', 'gana-con-colompro'));
}

// Obtener estado del juego
$game_state = GCC_Game_Engine::get_game_state($order_id);
if (!$game_state) {
    wp_die(__('Juego no encontrado', 'gana-con-colompro'));
}

$customer_name = $order->get_billing_first_name() ?: __('Amigo', 'gana-con-colompro');
$order_total = $order->get_total();
$levels = array(1 => 1, 2 => 2, 3 => 4, 4 => 8, 5 => 15, 6 => 30, 7 => 50, 8 => 100);

// Obtener colores personalizados
$color_win = gcc_get_option('color_win', '#28a745');
$color_repeat = gcc_get_option('color_repeat', '#007bff');
$color_lose = gcc_get_option('color_lose', '#dc3545');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html(gcc_get_option('game_title', 'Gana con Colompro')); ?></title>
    <?php wp_head(); ?>
</head>
<body class="gcc-game-page">
    <div class="gcc-game-container">
        <div class="gcc-game-header">
            <h1><?php echo esc_html(gcc_get_option('game_title', 'Gana con Colompro')); ?></h1>
            <p class="gcc-welcome">¡Hola <?php echo esc_html($customer_name); ?>! Gracias por tu compra #<?php echo $order_id; ?></p>
        </div>
        
        <!-- Barra de progreso -->
        <div class="gcc-progress-bar">
            <div class="gcc-levels">
                <?php 
                // Usar el nivel real del estado del juego
                $current_display_level = $game_state['current_level'];
                
                // Solo si nunca ha jugado (pending), mostrar nivel 1
                if ($game_state['status'] === 'pending' && $current_display_level == 0) {
                    $current_display_level = 1;
                }
                
                for ($i = 1; $i <= 8; $i++) : 
                ?>
                    <div class="gcc-level <?php echo $i <= $current_display_level ? 'active' : ''; ?>" data-level="<?php echo $i; ?>">
                        <span class="gcc-level-number"><?php echo $i; ?></span>
                        <span class="gcc-level-percentage"><?php echo isset($levels[$i]) ? $levels[$i] : 0; ?>%</span>
                    </div>
                <?php endfor; ?>
            </div>
            <div class="gcc-progress-fill" style="width: <?php echo ($current_display_level / 8 * 100); ?>%"></div>
        </div>
        
        <!-- Información del premio actual -->
        <div class="gcc-current-reward">
            <h2>Premio Actual</h2>
            <div class="gcc-reward-amount">
                <span class="gcc-percentage" id="gcc-current-percentage"><?php echo $game_state['reward_percentage']; ?>%</span>
                <span class="gcc-value" id="gcc-current-value"><?php echo wc_price($game_state['reward_amount']); ?></span>
            </div>
            <?php if ($game_state['status'] === 'pending') : ?>
                <p class="gcc-info-text">¡Ya tienes 1% garantizado! Gira para ganar más.</p>
            <?php elseif ($game_state['current_level'] > 1) : ?>
                <p class="gcc-info-text">Estás en el nivel <?php echo $game_state['current_level']; ?>. ¡Sigue jugando o reclama tu premio!</p>
            <?php endif; ?>
        </div>
        
        <!-- Contenedor de la ruleta -->
        <div class="gcc-wheel-container">
            <!-- Flecha indicadora -->
            <div class="gcc-wheel-arrow"></div>
            
            <!-- Ruleta -->
            <div class="gcc-wheel" id="gcc-wheel">
                <div class="gcc-wheel-inner">
                    <!-- SVG para mejor visualización -->
                    <svg viewBox="0 0 400 400" style="width: 100%; height: 100%;">
                        <!-- GANA 1 (0° - 60°) -->
                        <path d="M 200 200 L 200 5 A 195 195 0 0 1 368.75 100 Z" 
                              fill="<?php echo esc_attr($color_win); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- REPITE 1 (60° - 120°) -->
                        <path d="M 200 200 L 368.75 100 A 195 195 0 0 1 368.75 300 Z" 
                              fill="<?php echo esc_attr($color_repeat); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- PIERDE 1 (120° - 180°) -->
                        <path d="M 200 200 L 368.75 300 A 195 195 0 0 1 200 395 Z" 
                              fill="<?php echo esc_attr($color_lose); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- GANA 2 (180° - 240°) -->
                        <path d="M 200 200 L 200 395 A 195 195 0 0 1 31.25 300 Z" 
                              fill="<?php echo esc_attr($color_win); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- REPITE 2 (240° - 300°) -->
                        <path d="M 200 200 L 31.25 300 A 195 195 0 0 1 31.25 100 Z" 
                              fill="<?php echo esc_attr($color_repeat); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- PIERDE 2 (300° - 360°) -->
                        <path d="M 200 200 L 31.25 100 A 195 195 0 0 1 200 5 Z" 
                              fill="<?php echo esc_attr($color_lose); ?>" 
                              stroke="#333" 
                              stroke-width="3"/>
                        
                        <!-- Texto con rotación radial correcta -->
                        <g transform="translate(200,200)">
                            <!-- GANA 1 - rotación 30° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(30)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">GANA</text>
                            
                            <!-- REPITE 1 - rotación 90° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(90)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">REPITE</text>
                            
                            <!-- PIERDE 1 - rotación 150° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(150)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">PIERDE</text>
                            
                            <!-- GANA 2 - rotación 210° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(210)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">GANA</text>
                            
                            <!-- REPITE 2 - rotación 270° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(270)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">REPITE</text>
                            
                            <!-- PIERDE 2 - rotación 330° -->
                            <text x="0" y="-120" fill="white" font-size="24" font-weight="bold" 
                                  text-anchor="middle" transform="rotate(330)" 
                                  style="text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">PIERDE</text>
                        </g>
                    </svg>
                </div>
                
                <!-- Centro de la ruleta -->
                <div class="gcc-wheel-center">🎯</div>
            </div>
        </div>
        
        <!-- Botones de acción -->
        <div class="gcc-actions">
            <?php if ($game_state['can_play']) : ?>
                <button class="gcc-btn gcc-btn-spin" id="gcc-spin-button">
                    🎰 Girar la Ruleta
                </button>
            <?php endif; ?>
            
            <button class="gcc-btn gcc-btn-claim" 
                    id="gcc-claim-button" 
                    style="<?php echo ($game_state['status'] !== 'lost' && $game_state['status'] !== 'claimed') ? '' : 'display: none;'; ?>">
                🎁 Obtener mi Recompensa
            </button>
        </div>
        
        <!-- Reglas del juego -->
        <div class="gcc-rules">
            <h3>📋 Reglas del Juego</h3>
            <ul>
                <li><strong>GANA:</strong> Avanzás al siguiente nivel y aumenta tu premio</li>
                <li><strong>REPITE:</strong> Volvés a girar en el mismo nivel</li>
                <li><strong>PIERDE:</strong> Perdés todo y termina el juego</li>
                <li>Podés parar en cualquier momento y reclamar tu premio acumulado</li>
                <li>El premio máximo es del 100% en el nivel 8</li>
            </ul>
        </div>
        
        <!-- Estado del juego -->
        <?php if ($game_state['status'] === 'lost') : ?>
            <div class="gcc-game-over gcc-lost">
                <h2>😢 ¡Lo sentimos!</h2>
                <p>Has perdido en el nivel <?php echo $game_state['current_level']; ?>. ¡Mejor suerte la próxima vez!</p>
            </div>
        <?php elseif ($game_state['status'] === 'claimed') : ?>
            <div class="gcc-game-over gcc-claimed">
                <h2>🎉 ¡Felicitaciones!</h2>
                <p>Ya reclamaste tu premio del <?php echo $game_state['reward_percentage']; ?>%. Revisa tu email para el código del cupón.</p>
            </div>
        <?php elseif ($game_state['status'] === 'completed' && $game_state['current_level'] === 8) : ?>
            <div class="gcc-game-over gcc-completed">
                <h2>🏆 ¡INCREÍBLE!</h2>
                <p>¡Has llegado al nivel máximo! Reclama tu premio del 100% ahora.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Modal de resultado -->
    <div class="gcc-modal" id="gcc-result-modal">
        <div class="gcc-modal-content">
            <div class="gcc-modal-body">
                <div class="gcc-result-icon"></div>
                <h2 class="gcc-result-title"></h2>
                <p class="gcc-result-message"></p>
                <button class="gcc-btn gcc-btn-continue" id="gcc-continue-button">Continuar</button>
            </div>
        </div>
    </div>
    
    <!-- Modal de confirmación para reclamar -->
    <div class="gcc-modal" id="gcc-claim-modal">
        <div class="gcc-modal-content">
            <div class="gcc-modal-body">
                <h2>¿Estás seguro?</h2>
                <p>Vas a reclamar tu premio del <strong><span id="gcc-claim-percentage"><?php echo $game_state['reward_percentage']; ?></span>%</strong> (<span id="gcc-claim-amount"><?php echo wc_price($game_state['reward_amount']); ?></span>)</p>
                <p>Una vez que reclames, no podrás seguir jugando.</p>
                <div class="gcc-modal-actions">
                    <button class="gcc-btn gcc-btn-cancel" id="gcc-cancel-claim">Seguir Jugando</button>
                    <button class="gcc-btn gcc-btn-confirm" id="gcc-confirm-claim">Reclamar Premio</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sonidos -->
    <?php if (gcc_get_option('enable_sounds', true)) : ?>
        <audio id="gcc-sound-spin" preload="auto">
            <source src="<?php echo GCC_PLUGIN_URL; ?>assets/sounds/spin.mp3" type="audio/mpeg">
        </audio>
        <audio id="gcc-sound-win" preload="auto">
            <source src="<?php echo GCC_PLUGIN_URL; ?>assets/sounds/win.mp3" type="audio/mpeg">
        </audio>
        <audio id="gcc-sound-lose" preload="auto">
            <source src="<?php echo GCC_PLUGIN_URL; ?>assets/sounds/lose.mp3" type="audio/mpeg">
        </audio>
    <?php endif; ?>
    
    <!-- Estilos dinámicos -->
    <style>
        :root {
            --gcc-color-win: <?php echo esc_attr($color_win); ?>;
            --gcc-color-repeat: <?php echo esc_attr($color_repeat); ?>;
            --gcc-color-lose: <?php echo esc_attr($color_lose); ?>;
        }
    </style>
    
    <script>
    // Pasar el estado del juego a JavaScript
    window.gccGameState = <?php echo json_encode($game_state); ?>;
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>