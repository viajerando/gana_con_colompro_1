<?php
/**
 * Archivo: uninstall.php
 * Script de desinstalación del plugin
 */

// Si no es WordPress quien llama este archivo, salir
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Verificar permisos
if (!current_user_can('activate_plugins')) {
    return;
}

// Eliminar opciones
delete_option('gcc_settings');
delete_option('gcc_db_version');

// Eliminar tablas si el usuario lo desea
$remove_data = get_option('gcc_remove_data_on_uninstall', false);

if ($remove_data) {
    global $wpdb;
    
    // Eliminar tablas
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}gcc_coupons");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}gcc_spins");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}gcc_games");
    
    // Eliminar meta datos de pedidos
    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_gcc_game_token'");
    
    // Eliminar cupones generados
    $coupons = get_posts(array(
        'post_type' => 'shop_coupon',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_gcc_generated',
                'value' => 'yes'
            )
        )
    ));
    
    foreach ($coupons as $coupon) {
        wp_delete_post($coupon->ID, true);
    }
}

// Limpiar cron jobs
wp_clear_scheduled_hook('gcc_check_reminders');

// Limpiar eventos individuales
$crons = _get_cron_array();
if (!empty($crons)) {
    foreach ($crons as $timestamp => $cron) {
        foreach ($cron as $hook => $args) {
            if (strpos($hook, 'gcc_') === 0) {
                wp_unschedule_event($timestamp, $hook, array_keys($args)[0]);
            }
        }
    }
}

// Limpiar caché
wp_cache_flush();