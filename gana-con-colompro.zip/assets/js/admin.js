(function($) {
    'use strict';
    
    // Admin Controller
    const GCCAdmin = {
        // Initialize
        init: function() {
            this.bindEvents();
            this.initCharts();
        },
        
        // Bind events
        bindEvents: function() {
            // View details button
            $(document).on('click', '.gcc-view-details', function(e) {
                e.preventDefault();
                const gameId = $(this).data('game-id');
                GCCAdmin.showGameDetails(gameId);
            });
            
            // Close modal
            $(document).on('click', '.gcc-details-close, .gcc-modal-overlay', function() {
                GCCAdmin.closeModal();
            });
            
            // Export button
            $('.gcc-export-btn').on('click', function(e) {
                e.preventDefault();
                GCCAdmin.exportData();
            });
            
            // Settings validation
            if ($('.gcc-settings-container').length) {
                this.initSettingsValidation();
            }
        },
        
        // Initialize charts
        initCharts: function() {
            // Charts are initialized in the PHP template
            // This is just a placeholder for additional chart functionality
        },
        
        // Show game details
        showGameDetails: function(gameId) {
            // Create modal if it doesn't exist
            if (!$('.gcc-details-modal').length) {
                $('body').append(`
                    <div class="gcc-modal-overlay"></div>
                    <div class="gcc-details-modal">
                        <button class="gcc-details-close">&times;</button>
                        <div class="gcc-details-content">
                            <div class="gcc-loading"></div>
                        </div>
                    </div>
                `);
            }
            
            // Show modal with loading
            $('.gcc-modal-overlay, .gcc-details-modal').addClass('active');
            
            // Load game details via AJAX
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'gcc_get_game_details',
                    game_id: gameId,
                    nonce: $('#gcc_admin_nonce').val() || ''
                },
                success: function(response) {
                    if (response.success) {
                        GCCAdmin.displayGameDetails(response.data);
                    } else {
                        $('.gcc-details-content').html(
                            '<p class="gcc-message error">Error al cargar los detalles del juego.</p>'
                        );
                    }
                },
                error: function() {
                    $('.gcc-details-content').html(
                        '<p class="gcc-message error">Error de conexión.</p>'
                    );
                }
            });
        },
        
        // Display game details
        displayGameDetails: function(data) {
            let html = `
                <h3>Detalles del Juego - Pedido #${data.order_id}</h3>
                <table class="widefat">
                    <tr>
                        <th>Usuario:</th>
                        <td>${data.user_email}</td>
                    </tr>
                    <tr>
                        <th>Estado:</th>
                        <td><span class="gcc-status-badge gcc-status-${data.status}">${data.status_label}</span></td>
                    </tr>
                    <tr>
                        <th>Nivel Alcanzado:</th>
                        <td>${data.current_level}</td>
                    </tr>
                    <tr>
                        <th>Premio:</th>
                        <td>${data.reward_percentage}% (${data.reward_amount})</td>
                    </tr>
                    <tr>
                        <th>Cupón:</th>
                        <td>${data.coupon_code || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>Fecha Inicio:</th>
                        <td>${data.started_at || 'No iniciado'}</td>
                    </tr>
                    <tr>
                        <th>Fecha Fin:</th>
                        <td>${data.completed_at || 'No completado'}</td>
                    </tr>
                </table>
            `;
            
            // Add spin history if available
            if (data.spins && data.spins.length > 0) {
                html += '<div class="gcc-spin-history"><h4>Historial de Giros</h4>';
                
                data.spins.forEach(function(spin) {
                    html += `
                        <div class="gcc-spin-item">
                            <span class="gcc-spin-level">Nivel ${spin.level}:</span>
                            <span class="gcc-spin-result ${spin.result}">${spin.result_label}</span>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            $('.gcc-details-content').html(html);
        },
        
        // Close modal
        closeModal: function() {
            $('.gcc-modal-overlay, .gcc-details-modal').removeClass('active');
        },
        
        // Export data
        exportData: function() {
            window.location.href = ajaxurl + '?action=gcc_export_data&nonce=' + $('#gcc_admin_nonce').val();
        },
        
        // Initialize settings validation
        initSettingsValidation: function() {
            // Probability validation
            const probabilityInputs = $('.probability-input');
            
            probabilityInputs.on('input', function() {
                let total = 0;
                probabilityInputs.each(function() {
                    total += parseFloat($(this).val()) || 0;
                });
                
                const totalDisplay = $('#probability-total');
                totalDisplay.text(total.toFixed(1));
                
                if (Math.abs(total - 100) > 0.1) {
                    totalDisplay.css('color', '#dc3545');
                    $('#submit').prop('disabled', true);
                } else {
                    totalDisplay.css('color', '#28a745');
                    $('#submit').prop('disabled', false);
                }
            });
            
            // Color picker preview
            $('input[type="color"]').on('change', function() {
                const colorType = $(this).attr('id').replace('color_', '');
                $(this).closest('td').append(
                    `<span class="color-preview" style="background: ${$(this).val()};"></span>`
                );
            });
            
            // Form submission validation
            $('form').on('submit', function(e) {
                let total = 0;
                probabilityInputs.each(function() {
                    total += parseFloat($(this).val()) || 0;
                });
                
                if (Math.abs(total - 100) > 0.1) {
                    e.preventDefault();
                    alert('Las probabilidades deben sumar exactamente 100%');
                    return false;
                }
            });
        }
    };
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        if ($('.gcc-admin-wrap, .gcc-settings-container').length) {
            GCCAdmin.init();
        }
    });
    
})(jQuery);