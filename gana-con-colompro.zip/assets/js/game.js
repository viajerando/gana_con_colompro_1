(function($) {
    'use strict';
    
    // Game Controller
    const GCCGame = {
        // Properties
        isSpinning: false,
        currentLevel: window.gccGameState.current_level || 0,
        canPlay: window.gccGameState.can_play || false,
        canClaim: window.gccGameState.can_claim || false,
        currentRotation: 0, // Añadir para trackear la rotación actual
        
        // DOM Elements
        wheel: null,
        spinButton: null,
        claimButton: null,
        resultModal: null,
        claimModal: null,
        
        // Initialize
        init: function() {
            this.cacheElements();
            this.bindEvents();
            
            // Usar siempre el nivel real del estado del juego
            this.currentLevel = window.gccGameState.current_level;
            
            // Solo si está pendiente y el nivel es 0, mostrar como nivel 1
            if (window.gccGameState.status === 'pending' && this.currentLevel === 0) {
                this.currentLevel = 1;
            }
            
            this.updateUI();
            this.updateProgressBar();
            
            // Mostrar información adicional si está en un nivel avanzado
            if (this.currentLevel > 1 && window.gccGameState.status === 'playing') {
                console.log('Juego en progreso - Nivel actual: ' + this.currentLevel);
            }
        },
        
        // Cache DOM elements
        cacheElements: function() {
            this.wheel = $('#gcc-wheel .gcc-wheel-inner');
            this.spinButton = $('#gcc-spin-button');
            this.claimButton = $('#gcc-claim-button');
            this.resultModal = $('#gcc-result-modal');
            this.claimModal = $('#gcc-claim-modal');
        },
        
        // Bind events
        bindEvents: function() {
            this.spinButton.on('click', () => this.spin());
            this.claimButton.on('click', () => this.showClaimModal());
            $('#gcc-continue-button').on('click', () => this.closeResultModal());
            $('#gcc-cancel-claim').on('click', () => this.closeClaimModal());
            $('#gcc-confirm-claim').on('click', () => this.claimReward());
            
            // Close modals on background click
            $('.gcc-modal').on('click', function(e) {
                if ($(e.target).hasClass('gcc-modal')) {
                    $(this).removeClass('active');
                }
            });
        },
        
        // Update UI based on game state
        updateUI: function() {
            if (!this.canPlay) {
                this.spinButton.prop('disabled', true);
            }
            
            // Mostrar botón de reclamar si hay premio
            if (window.gccGameState.reward_percentage > 0 || window.gccGameState.status === 'pending') {
                this.claimButton.show().css('display', 'inline-block');
            }
            
            // Update progress bar
            this.updateProgressBar();
        },
        
        // Spin the wheel
        spin: function() {
            if (this.isSpinning || !this.canPlay) return;
            
            this.isSpinning = true;
            this.spinButton.prop('disabled', true).addClass('loading');
            
            // Play spin sound
            this.playSound('spin');
            
            // Debug info
            console.log('Spinning wheel with data:', {
                action: 'gcc_spin_wheel',
                nonce: gcc_ajax.nonce,
                order_id: gcc_ajax.order_id,
                token: gcc_ajax.token
            });
            
            // Send AJAX request
            $.ajax({
                url: gcc_ajax.url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'gcc_spin_wheel',
                    nonce: gcc_ajax.nonce,
                    order_id: gcc_ajax.order_id,
                    token: gcc_ajax.token
                },
                success: (response) => {
                    console.log('Spin response:', response);
                    if (response.success) {
                        this.animateWheel(response.data);
                    } else {
                        this.showError(response.data || 'Error desconocido');
                        this.isSpinning = false;
                        this.spinButton.prop('disabled', false).removeClass('loading');
                    }
                },
                error: (xhr, status, error) => {
                    console.error('AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    this.showError('Error de conexión. Por favor intenta de nuevo.');
                    this.isSpinning = false;
                    this.spinButton.prop('disabled', false).removeClass('loading');
                }
            });
        },
        
        // Animate wheel rotation - VERSIÓN CORREGIDA
        animateWheel: function(data) {
            // La ruleta tiene 6 casillas, cada una de 60 grados
            const degreesPerSection = 60;
            
            // Mapeo de resultados a posiciones de casillas
            // Importante: las posiciones deben coincidir con el orden en el SVG
            const resultToPosition = {
                'win': [0, 3],    // GANA está en posición 0 y 3
                'repeat': [1, 4], // REPITE está en posición 1 y 4
                'lose': [2, 5]    // PIERDE está en posición 2 y 5
            };
            
            // Obtener las posiciones posibles para este resultado
            const possiblePositions = resultToPosition[data.result];
            if (!possiblePositions) {
                console.error('Resultado desconocido:', data.result);
                return;
            }
            
            // Elegir aleatoriamente una de las dos posiciones posibles
            const targetPosition = possiblePositions[Math.floor(Math.random() * possiblePositions.length)];
            
            // Número de vueltas completas (aleatorio entre 7 y 9)
            const fullSpins = 7 + Math.floor(Math.random() * 3);
            
            // Para que la casilla quede bajo la flecha (que está arriba), 
            // necesitamos que esa casilla esté en la posición 0° (arriba)
            // Como las casillas están numeradas en sentido horario desde arriba:
            // Posición 0 = 0°, Posición 1 = 60°, etc.
            // Para que una casilla quede arriba, debemos rotar la ruleta de modo que
            // esa casilla termine en 0°
            
            // La ruleta gira en sentido horario, así que para llevar la casilla X a la posición 0°
            // debemos rotar: 360° - (X * 60°)
            const targetAngle = 360 - (targetPosition * degreesPerSection);
            
            // Añadir un pequeño offset aleatorio para que no caiga exactamente en el centro
            const randomOffset = -15 + Math.random() * 30; // Entre -15 y +15 grados
            
            // Calcular la rotación total
            const totalRotation = (fullSpins * 360) + targetAngle + randomOffset;
            
            console.log('Animación de ruleta:', {
                resultado: data.result,
                posicionObjetivo: targetPosition,
                anguloObjetivo: targetAngle,
                vueltasCompletas: fullSpins,
                offset: randomOffset,
                rotacionTotal: totalRotation
            });
            
            // Aplicar la rotación
            this.wheel.css({
                'transform': 'rotate(' + (this.currentRotation + totalRotation) + 'deg)',
                'transition': 'transform 4s cubic-bezier(0.25, 0.1, 0.25, 1)'
            });
            
            // Actualizar la rotación actual
            this.currentRotation += totalRotation;
            
            // Add spinning class
            this.wheel.addClass('spinning');
            
            // Wait for animation to complete
            setTimeout(() => {
                this.wheel.removeClass('spinning');
                this.handleSpinResult(data);
            }, 4000); // 4 segundos de duración
        },
        
        // Handle spin result
        handleSpinResult: function(data) {
            this.isSpinning = false;
            
            // Update game state
            this.currentLevel = data.level;
            window.gccGameState.reward_percentage = data.reward_percentage;
            window.gccGameState.reward_amount = data.reward_amount;
            
            // Play result sound
            if (data.result === 'win') {
                this.playSound('win');
            } else if (data.result === 'lose') {
                this.playSound('lose');
            }
            
            // Show result modal
            this.showResultModal(data);
            
            // Update UI
            this.updateProgressBar();
            this.updateRewardDisplay(data);
            
            // Handle game over states
            if (data.game_over) {
                this.canPlay = false;
                this.spinButton.prop('disabled', true);
                this.claimButton.hide();
            } else if (data.game_completed) {
                this.canPlay = false;
                this.canClaim = true;
                this.spinButton.prop('disabled', true);
                this.claimButton.show().css('display', 'inline-block');
            } else {
                this.spinButton.prop('disabled', false);
                if (data.reward_percentage > 0) {
                    this.canClaim = true;
                    this.claimButton.show().css('display', 'inline-block');
                }
            }
        },
        
        // Show result modal
        showResultModal: function(data) {
            const modal = this.resultModal;
            const icon = modal.find('.gcc-result-icon');
            const title = modal.find('.gcc-result-title');
            const message = modal.find('.gcc-result-message');
            
            // Set content based on result
            switch(data.result) {
                case 'win':
                    icon.html('🎉');
                    title.text('¡GANASTE!');
                    message.text('Avanzaste al nivel ' + data.level + '. Tu premio ahora es del ' + data.reward_percentage + '%');
                    break;
                    
                case 'repeat':
                    icon.html('🔄');
                    title.text('REPITES');
                    message.text('Volvé a girar en el nivel ' + this.currentLevel);
                    break;
                    
                case 'lose':
                    icon.html('😢');
                    title.text('PERDISTE');
                    message.text('Lo sentimos, perdiste todo. ¡Mejor suerte la próxima!');
                    break;
            }
            
            // Special messages
            if (data.game_completed) {
                icon.html('🏆');
                title.text('¡INCREÍBLE!');
                message.text('¡Llegaste al nivel máximo! Tienes un 100% de descuento. ¡Reclámalo ahora!');
            }
            
            modal.addClass('active');
        },
        
        // Close result modal
        closeResultModal: function() {
            this.resultModal.removeClass('active');
            this.spinButton.removeClass('loading');
        },
        
        // Show claim modal
        showClaimModal: function() {
            // Actualizar los valores en el modal con los valores actuales
            $('#gcc-claim-percentage').text(window.gccGameState.reward_percentage);
            
            // Usar el valor formateado que ya viene del servidor o formatear localmente
            var formattedAmount = window.gccGameState.reward_amount;
            if (typeof formattedAmount === 'number') {
                formattedAmount = '$' + formattedAmount.toFixed(2);
            }
            $('#gcc-claim-amount').html(formattedAmount);
            
            this.claimModal.addClass('active');
        },
        
        // Close claim modal
        closeClaimModal: function() {
            this.claimModal.removeClass('active');
        },
        
        // Claim reward
        claimReward: function() {
            this.claimButton.prop('disabled', true);
            $('#gcc-confirm-claim').prop('disabled', true);
            
            console.log('Claiming reward with data:', {
                action: 'gcc_claim_reward',
                nonce: gcc_ajax.nonce,
                order_id: gcc_ajax.order_id,
                token: gcc_ajax.token
            });
            
            $.ajax({
                url: gcc_ajax.url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'gcc_claim_reward',
                    nonce: gcc_ajax.nonce,
                    order_id: gcc_ajax.order_id,
                    token: gcc_ajax.token
                },
                success: (response) => {
                    console.log('Claim response:', response);
                    if (response.success) {
                        this.handleClaimSuccess(response.data);
                    } else {
                        this.showError(response.data || 'Error al reclamar el premio');
                        this.claimButton.prop('disabled', false);
                        $('#gcc-confirm-claim').prop('disabled', false);
                    }
                },
                error: (xhr, status, error) => {
                    console.error('AJAX Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    this.showError('Error de conexión. Por favor intenta de nuevo.');
                    this.claimButton.prop('disabled', false);
                    $('#gcc-confirm-claim').prop('disabled', false);
                }
            });
        },
        
        // Handle successful claim
        handleClaimSuccess: function(data) {
            this.closeClaimModal();
            
            // Show success message
            const successHtml = `
                <div class="gcc-game-over gcc-claimed">
                    <h2>🎉 ¡Felicitaciones!</h2>
                    <p>Has reclamado exitosamente tu premio del ${data.reward_percentage}% (${data.reward_amount})</p>
                    <p>Tu código de cupón es: <strong>${data.coupon_code}</strong></p>
                    <p><em>${data.message}</em></p>
                    <p>También te enviamos el cupón por email.</p>
                </div>
            `;
            
            $('.gcc-actions').after(successHtml);
            
            // Hide buttons
            this.spinButton.hide();
            this.claimButton.hide();
            
            // Play win sound
            this.playSound('win');
        },
        
        // Update progress bar
        updateProgressBar: function() {
            const percentage = (this.currentLevel / 8) * 100;
            $('.gcc-progress-fill').css('width', percentage + '%');
            
            // Update level indicators
            $('.gcc-level').each(function(index) {
                const level = index + 1;
                if (level <= GCCGame.currentLevel) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        },
        
        // Update reward display
        updateRewardDisplay: function(data) {
            if (data.reward_percentage !== undefined) {
                $('#gcc-current-percentage').text(data.reward_percentage + '%');
                window.gccGameState.reward_percentage = data.reward_percentage;
            }
            if (data.reward_amount !== undefined) {
                $('#gcc-current-value').html(data.reward_amount);
                window.gccGameState.reward_amount = data.reward_amount;
            }
        },
        
        // Play sound
        playSound: function(type) {
            const sound = $('#gcc-sound-' + type).get(0);
            if (sound) {
                sound.currentTime = 0;
                sound.play().catch(() => {
                    // Handle autoplay restrictions
                });
            }
        },
        
        // Show error message
        showError: function(message) {
            // Crear modal de error si no existe
            if (!$('#gcc-error-modal').length) {
                $('body').append(`
                    <div class="gcc-modal" id="gcc-error-modal">
                        <div class="gcc-modal-content">
                            <div class="gcc-modal-body">
                                <div class="gcc-result-icon">❌</div>
                                <h2 class="gcc-result-title">Error</h2>
                                <p class="gcc-result-message"></p>
                                <button class="gcc-btn gcc-btn-continue" onclick="jQuery('#gcc-error-modal').removeClass('active')">Cerrar</button>
                            </div>
                        </div>
                    </div>
                `);
            }
            
            $('#gcc-error-modal .gcc-result-message').text(message);
            $('#gcc-error-modal').addClass('active');
        }
    };
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        GCCGame.init();
    });
    
})(jQuery);